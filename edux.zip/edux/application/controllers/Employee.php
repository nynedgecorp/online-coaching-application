<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Employee extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('user_logged_in'))
		{
            redirect(base_url().'login', 'refresh');
        }
		$this->load->model('front/common_model');
	}
	
	public function index()
	{
		redirect(base_url().'employee/manage', 'refresh');
	}
	
	public function manage()
	{
		$total_row = $this->common_model->record_count('table_employees', '');
		$config['base_url'] = $this->config->base_url().'employee/manage/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 30;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
		
		$this->pagination->initialize($config);
		if($this->uri->segment(3))
		{
			$page = ($this->uri->segment(3)) ;
		}
		else
		{
			$page = 1;
		}
		$data['results'] = $this->common_model->fetch_data('table_employees', '', 'employee_id', 'DESC', $config['per_page'], $page);
		$data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}
		$data['meta_title'] = 'Manage Employee';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/employee/manage_employee',$data);
	}
	
	public function add()
	{
		if ($this->input->post('submit')) 
		{
            $err = 0;
            $email_check = $this->common_model->get_list('table_employees', "email='".$this->input->post('email')."'");
            $username_check = $this->common_model->get_list('table_employees', "username='".$this->input->post('username')."'");
            
            if($email_check != FALSE)
            {
                $data['error_message'] = 'Email already exists. Please choose different one.';
                $err = 1;
            }
            if($username_check != FALSE)
            {
                $data['error_message'] = 'Username already exists. Please choose different one.';
                $err = 1;
            }
            
            if($err != 1)
            {

                $input_user = array(
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'password' => md5($this->input->post('password')),
                    'rid' => 2,
                    'created' => date('d-m-Y h:i:s')
                    );
                
                $this->common_model->add_data('table_users', $input_user);    
                $last_id_arr = $this->common_model->get_last_id('table_users', 'uid');
                $last_id = $last_id_arr[0]->uid; 

                $input_data = array(
                        'uid' => $last_id,
                        'name' => $this->input->post('name'),
                        'email' => $this->input->post('email'),
                        'phone' => $this->input->post('phone'),
                        'alternate_no' => $this->input->post('alternate_no'),
                        'address' => $this->input->post('address'),
                        'pin_code' => $this->input->post('pin_code'),
                        'username' => $this->input->post('username'),
                        'created' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->add_data('table_employees', $input_data);

                $this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
                redirect(base_url().'employee/manage', 'refresh');
            }
        }

		$data['meta_title'] = 'Add Employee';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/employee/add_employee',$data);
	}
	
	public function status()
	{
		$id = $this->uri->segment(3);
        $status = $this->uri->segment(4);
        $result = $this->common_model->get_data('table_employees', 'employee_id', $id);
        $uid = $result[0]->uid;
		$input_data = array(
					'status' => $status,
					);
        $this->common_model->update_data('table_employees', 'employee_id', $id, $input_data);
        $this->common_model->update_data('table_users', 'uid', $uid, $input_data);
		$this->session->set_userdata('messages', array('msg' => 'Status Updated'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
	public function edit()
	{
        $id = $this->uri->segment(3);
        
        if ($this->input->post('submit')) 
		{
            $err = 0;
            $email_check = $this->common_model->get_list('table_employees', "email='".$this->input->post('email')."' AND employee_id<>".$id."");
            $username_check = $this->common_model->get_list('table_employees', "username='".$this->input->post('username')."' AND employee_id<>".$id."");
            
            if($email_check != FALSE)
            {
                $data['error_message'] = 'Email already exists. Please choose different one.';
                $err = 1;
            }
            if($username_check != FALSE)
            {
                $data['error_message'] = 'Username already exists. Please choose different one.';
                $err = 1;
            }

            $employee = $this->common_model->get_data('table_employees', 'employee_id', $id);
            $uid = $employee[0]->uid;
            
            if($err != 1)
            {

                $input_user = array(
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'modified' => date('d-m-Y h:i:s')
                    );
                if($this->input->post('password') != '')
                {		
                    $input_user['password'] = md5($this->input->post('password'));
                }    
                
                $this->common_model->update_data('table_users', 'uid', $uid, $input_user);    

                $input_data = array(
                        'name' => $this->input->post('name'),
                        'email' => $this->input->post('email'),
                        'phone' => $this->input->post('phone'),
                        'alternate_no' => $this->input->post('alternate_no'),
                        'address' => $this->input->post('address'),
                        'pin_code' => $this->input->post('pin_code'),
                        'username' => $this->input->post('username'),
                        'modified' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->update_data('table_employees', 'employee_id', $id, $input_data);
                $this->session->set_userdata('messages', array('msg' => 'Details successfully updated'));
                redirect(base_url().'employee/manage', 'refresh');
            }
        }
        
        $data['result'] = $this->common_model->get_data('table_employees', 'employee_id', $id);
		$data['meta_title'] = 'Edit Employee';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/employee/edit_employee',$data);
	}
	
	public function view()
	{
        $id = $this->uri->segment(3);
		$data['result'] = $this->common_model->get_data('table_employees', 'employee_id', $id);
		$data['meta_title'] = 'View Employee';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/employee/view_employee',$data);
	}
	
	public function delete()
	{
        $id = $this->uri->segment(3);
        
        $emp = $this->common_model->get_data('table_employees', 'employee_id', $id);

        $this->common_model->delete_data('table_users', 'uid', $emp[0]->uid);
        $this->common_model->delete_data('table_employees', 'employee_id', $id);
		$this->session->set_userdata('messages', array('msg' => 'Successfully Deleted'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
}
