<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Student extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('user_logged_in'))
		{
            redirect(base_url().'login', 'refresh');
        }
		$this->load->model('front/common_model');
	}
	
	public function index()
	{
		redirect(base_url().'student/manage', 'refresh');
	}
	
	public function manage()
	{
		$total_row = $this->common_model->record_count('table_students', '');
		$config['base_url'] = $this->config->base_url().'student/manage/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 30;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
        $config['reuse_query_string'] = TRUE;
		
		$this->pagination->initialize($config);
		if($this->uri->segment(3))
		{
			$page = ($this->uri->segment(3)) ;
		}
		else
		{
			$page = 1;
		}
        if(isset($_GET['course_id']) && $_GET['course_id'])
		{
            $data['results'] = $this->common_model->fetch_data('table_students', 'course_id='.$_GET['course_id'], 'student_id', 'DESC', $config['per_page'], $page);
		}
		else
		{
			$data['results'] = $this->common_model->fetch_data('table_students', '', 'student_id', 'DESC', $config['per_page'], $page);
		}
		$data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}

        $data['courses'] = $this->common_model->get_data('table_courses', 'status', '1');
		$data['meta_title'] = 'Manage Student';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/student/manage_student',$data);
	}
	
	public function add()
	{
		if ($this->input->post('submit')) 
		{
            $err = $err1 = 0;
            $photo = '';
            $qualification_file = '';
            $email_check = $this->common_model->get_list('table_students', "email='".$this->input->post('email')."'");
            $username_check = $this->common_model->get_list('table_students', "username='".$this->input->post('phone')."'");
            
            if($email_check != FALSE)
            {
                $data['error_message'] = 'Email already exists. Please choose different one.';
                $err = 1;
            }
            if($username_check != FALSE)
            {
                $data['error_message'] = 'Phone already exists. Please choose different one.';
                $err = 1;
            }

            if($err != 1)
            {
                if($_FILES['photo']['name'] != '')
                {
                    $config1['upload_path'] = './uploads/student/';
                    $config1['allowed_types'] = 'jpg|jpeg|png|gif';
                    $config1['overwrite'] = TRUE;
                    $config1['encrypt_name'] = TRUE;
                    
                    if (!is_dir($config1['upload_path'])) {
                        mkdir($config1['upload_path'], 0777, TRUE);
                    }  
            
                    $this->upload->initialize($config1);
                    
                    if (!$this->upload->do_upload('photo') && $_FILES['photo']['name'] != '')
                    {
                        $data['error_message'] = $this->upload->display_errors();
                        $err1 = 1;
                    }
                    else
                    {
                        $file_data1 = $this->upload->data();
                        $photo = $file_data1['file_name'];
                        $err1 = 0;
                    }
                }

                if($_FILES['qualification_file']['name'] != '')
                {
                    $config2['upload_path'] = './uploads/student/';
                    $config2['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                    $config2['overwrite'] = TRUE;
                    $config2['encrypt_name'] = TRUE;
                    
                    if (!is_dir($config2['upload_path'])) {
                        mkdir($config2['upload_path'], 0777, TRUE);
                    }  
            
                    $this->upload->initialize($config2);
                    
                    if (!$this->upload->do_upload('qualification_file') && $_FILES['qualification_file']['name'] != '')
                    {
                        $data['error_message'] = $this->upload->display_errors();
                        $err1 = 1;
                    }
                    else
                    {
                        $file_data2 = $this->upload->data();
                        $qualification_file = $file_data2['file_name'];
                        $err1 = 0;
                    }
                }
            }

            if($err != 1 && $err1 != 1)
            {

                $input_user = array(
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('phone'),
                    'password' => md5($this->input->post('password')),
                    'rid' => 3,
                    'created' => date('d-m-Y h:i:s')
                    );
                
                $this->common_model->add_data('table_users', $input_user);    
                $last_id_arr = $this->common_model->get_last_id('table_users', 'uid');
                $last_id = $last_id_arr[0]->uid; 

                $input_data = array(
                        'uid' => $last_id,
                        'batch_id' => $this->input->post('batch_id'),
                        'course_id' => $this->input->post('course_id'),
                        'phase_id' => $this->input->post('phase_id'),
                        'name' => $this->input->post('name'),
                        'email' => $this->input->post('email'),
                        'phone' => $this->input->post('phone'),
                        'alternate_no' => $this->input->post('alternate_no'),
                        'qual_academic_1' => $this->input->post('qual_academic_1'),
                        'qual_division_1' => $this->input->post('qual_division_1'),
                        'qual_year_1' => $this->input->post('qual_year_1'),
                        'qual_school_1' => $this->input->post('qual_school_1'),
                        'qual_subject_1' => $this->input->post('qual_subject_1'),
                        'qual_academic_2' => $this->input->post('qual_academic_2'),
                        'qual_division_2' => $this->input->post('qual_division_2'),
                        'qual_year_2' => $this->input->post('qual_year_2'),
                        'qual_school_2' => $this->input->post('qual_school_2'),
                        'qual_subject_2' => $this->input->post('qual_subject_2'),
                        'qual_academic_3' => $this->input->post('qual_academic_3'),
                        'qual_division_3' => $this->input->post('qual_division_3'),
                        'qual_year_3' => $this->input->post('qual_year_3'),
                        'qual_school_3' => $this->input->post('qual_school_3'),
                        'qual_subject_3' => $this->input->post('qual_subject_3'),
                        'qual_academic_4' => $this->input->post('qual_academic_4'),
                        'qual_division_4' => $this->input->post('qual_division_4'),
                        'qual_year_4' => $this->input->post('qual_year_4'),
                        'qual_school_4' => $this->input->post('qual_school_4'),
                        'qual_subject_4' => $this->input->post('qual_subject_4'),
                        'qual_academic_5' => $this->input->post('qual_academic_5'),
                        'qual_division_5' => $this->input->post('qual_division_5'),
                        'qual_year_5' => $this->input->post('qual_year_5'),
                        'qual_school_5' => $this->input->post('qual_school_5'),
                        'qual_subject_5' => $this->input->post('qual_subject_5'),
                        'qual_academic_6' => $this->input->post('qual_academic_6'),
                        'qual_division_6' => $this->input->post('qual_division_6'),
                        'qual_year_6' => $this->input->post('qual_year_6'),
                        'qual_school_6' => $this->input->post('qual_school_6'),
                        'qual_subject_6' => $this->input->post('qual_subject_6'),
                        'qual_academic_7' => $this->input->post('qual_academic_7'),
                        'qual_division_7' => $this->input->post('qual_division_7'),
                        'qual_year_7' => $this->input->post('qual_year_7'),
                        'qual_school_7' => $this->input->post('qual_school_7'),
                        'qual_subject_7' => $this->input->post('qual_subject_7'),
                        'qualification' => $this->input->post('qualification'),
                        'qualification_file' => $qualification_file,
                        'address' => $this->input->post('address'),
                        'pin_code' => $this->input->post('pin_code'),
                        'gender' => $this->input->post('gender'),
                        'admission_date' => $this->input->post('admission_date'),
                        'dob' => $this->input->post('dob'),
                        'candidate_type' => $this->input->post('candidate_type'),
                        'photo' => $photo,
                        'username' => $this->input->post('phone'),
                        'payment_mode' => $this->input->post('payment_mode'),
                        'payment_no' => $this->input->post('payment_no'),
                        'payment_date' => $this->input->post('payment_date'),
                        'created' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->add_data('table_students', $input_data);

                $this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
                redirect(base_url().'student/manage', 'refresh');
            }
        }

        $data['batches'] = $this->common_model->get_data('table_batches', 'status', '1');
        $data['courses'] = $this->common_model->get_data('table_courses', 'status', '1');
        $data['phases'] = $this->common_model->get_data('table_phases', 'status', '1');
		$data['meta_title'] = 'Add Student';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/student/add_student',$data);
	}
	
	public function status()
	{
		$id = $this->uri->segment(3);
        $status = $this->uri->segment(4);
        $result = $this->common_model->get_data('table_students', 'student_id', $id);
        $uid = $result[0]->uid;
		$input_data = array(
					'status' => $status,
					);
        $this->common_model->update_data('table_students', 'student_id', $id, $input_data);
        $this->common_model->update_data('table_users', 'uid', $uid, $input_data);
		$this->session->set_userdata('messages', array('msg' => 'Status Updated'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
	public function edit()
	{
        $id = $this->uri->segment(3);
        
        if ($this->input->post('submit')) 
		{
            $err = $err1 = 0;
            $photo = '';
            $qualification_file = '';
            $email_check = $this->common_model->get_list('table_students', "email='".$this->input->post('email')."' AND student_id<>".$id."");
            $username_check = $this->common_model->get_list('table_students', "username='".$this->input->post('phone')."' AND student_id<>".$id."");
            
            if($email_check != FALSE)
            {
                $data['error_message'] = 'Email already exists. Please choose different one.';
                $err = 1;
            }
            if($username_check != FALSE)
            {
                $data['error_message'] = 'Phone already exists. Please choose different one.';
                $err = 1;
            }

            if($err != 1)
            {
                if($_FILES['photo']['name'] != '')
                {
                    $config1['upload_path'] = './uploads/student/';
                    $config1['allowed_types'] = 'jpg|jpeg|png|gif';
                    $config1['overwrite'] = TRUE;
                    $config1['encrypt_name'] = TRUE;
                    
                    if (!is_dir($config1['upload_path'])) {
                        mkdir($config1['upload_path'], 0777, TRUE);
                    }  
            
                    $this->upload->initialize($config1);
                    
                    if (!$this->upload->do_upload('photo') && $_FILES['photo']['name'] != '')
                    {
                        $data['error_message'] = $this->upload->display_errors();
                        $err = 1;
                    }
                    else
                    {
                        $file_data1 = $this->upload->data();
                        $photo = $file_data1['file_name'];
                        $err = 0;
                    }
                }

                if($_FILES['qualification_file']['name'] != '')
                {
                    $config2['upload_path'] = './uploads/student/';
                    $config2['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                    $config2['overwrite'] = TRUE;
                    $config2['encrypt_name'] = TRUE;
                    
                    if (!is_dir($config2['upload_path'])) {
                        mkdir($config2['upload_path'], 0777, TRUE);
                    }  
            
                    $this->upload->initialize($config2);
                    
                    if (!$this->upload->do_upload('qualification_file') && $_FILES['qualification_file']['name'] != '')
                    {
                        $data['error_message'] = $this->upload->display_errors();
                        $err1 = 1;
                    }
                    else
                    {
                        $file_data2 = $this->upload->data();
                        $qualification_file = $file_data2['file_name'];
                        $err1 = 0;
                    }
                }
            }    

            $student = $this->common_model->get_data('table_students', 'student_id', $id);
            $uid = $student[0]->uid;
            
            if($err != 1 && $err1 != 1)
            {

                $input_user = array(
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('phone'),
                    'modified' => date('d-m-Y h:i:s')
                    );
                if($this->input->post('password') != '')
                {		
                    $input_user['password'] = md5($this->input->post('password'));
                }    
                
                $this->common_model->update_data('table_users', 'uid', $uid, $input_user);    

                $input_data = array(
                        'batch_id' => $this->input->post('batch_id'),
                        'course_id' => $this->input->post('course_id'),
                        'phase_id' => $this->input->post('phase_id'),
                        'name' => $this->input->post('name'),
                        'email' => $this->input->post('email'),
                        'phone' => $this->input->post('phone'),
                        'alternate_no' => $this->input->post('alternate_no'),
                        'qual_academic_1' => $this->input->post('qual_academic_1'),
                        'qual_division_1' => $this->input->post('qual_division_1'),
                        'qual_year_1' => $this->input->post('qual_year_1'),
                        'qual_school_1' => $this->input->post('qual_school_1'),
                        'qual_subject_1' => $this->input->post('qual_subject_1'),
                        'qual_academic_2' => $this->input->post('qual_academic_2'),
                        'qual_division_2' => $this->input->post('qual_division_2'),
                        'qual_year_2' => $this->input->post('qual_year_2'),
                        'qual_school_2' => $this->input->post('qual_school_2'),
                        'qual_subject_2' => $this->input->post('qual_subject_2'),
                        'qual_academic_3' => $this->input->post('qual_academic_3'),
                        'qual_division_3' => $this->input->post('qual_division_3'),
                        'qual_year_3' => $this->input->post('qual_year_3'),
                        'qual_school_3' => $this->input->post('qual_school_3'),
                        'qual_subject_3' => $this->input->post('qual_subject_3'),
                        'qual_academic_4' => $this->input->post('qual_academic_4'),
                        'qual_division_4' => $this->input->post('qual_division_4'),
                        'qual_year_4' => $this->input->post('qual_year_4'),
                        'qual_school_4' => $this->input->post('qual_school_4'),
                        'qual_subject_4' => $this->input->post('qual_subject_4'),
                        'qual_academic_5' => $this->input->post('qual_academic_5'),
                        'qual_division_5' => $this->input->post('qual_division_5'),
                        'qual_year_5' => $this->input->post('qual_year_5'),
                        'qual_school_5' => $this->input->post('qual_school_5'),
                        'qual_subject_5' => $this->input->post('qual_subject_5'),
                        'qual_academic_6' => $this->input->post('qual_academic_6'),
                        'qual_division_6' => $this->input->post('qual_division_6'),
                        'qual_year_6' => $this->input->post('qual_year_6'),
                        'qual_school_6' => $this->input->post('qual_school_6'),
                        'qual_subject_6' => $this->input->post('qual_subject_6'),
                        'qual_academic_7' => $this->input->post('qual_academic_7'),
                        'qual_division_7' => $this->input->post('qual_division_7'),
                        'qual_year_7' => $this->input->post('qual_year_7'),
                        'qual_school_7' => $this->input->post('qual_school_7'),
                        'qual_subject_7' => $this->input->post('qual_subject_7'),
                        'qualification' => $this->input->post('qualification'),
                        'address' => $this->input->post('address'),
                        'pin_code' => $this->input->post('pin_code'),
                        'gender' => $this->input->post('gender'),
                        'admission_date' => $this->input->post('admission_date'),
                        'dob' => $this->input->post('dob'),
                        'candidate_type' => $this->input->post('candidate_type'),
                        'username' => $this->input->post('phone'),
                        'payment_mode' => $this->input->post('payment_mode'),
                        'payment_no' => $this->input->post('payment_no'),
                        'payment_date' => $this->input->post('payment_date'),
                        'modified' => date('d-m-Y h:i:s')
                        ); 
                        
                if($_FILES['photo']['name'] != '')
                {		
                    $input_data['photo'] = $photo;
                } 
                if($_FILES['qualification_file']['name'] != '')
                {		
                    $input_data['qualification_file'] = $qualification_file;
                }        
                                
                $this->common_model->update_data('table_students', 'student_id', $id, $input_data);
                $this->session->set_userdata('messages', array('msg' => 'Details successfully updated'));
                redirect(base_url().'student/manage', 'refresh');
            }
        }
        
        $data['batches'] = $this->common_model->get_data('table_batches', 'status', '1');
        $data['courses'] = $this->common_model->get_data('table_courses', 'status', '1');
        $data['phases'] = $this->common_model->get_data('table_phases', 'status', '1');
        $data['result'] = $this->common_model->get_data('table_students', 'student_id', $id);
		$data['meta_title'] = 'Edit Student';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/student/edit_student',$data);
	}
	
	public function view()
	{
        $id = $this->uri->segment(3);
		$data['result'] = $this->common_model->get_data('table_students', 'student_id', $id);
		$data['meta_title'] = 'View Student';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/student/view_student',$data);
	}
	
	public function delete()
	{
        $id = $this->uri->segment(3);
        
        $students = $this->common_model->get_data('table_students', 'student_id', $id);

        if($students[0]->photo != ''){ unlink('uploads/student/'.$students[0]->photo); }

        $this->common_model->delete_data('table_users', 'uid', $students[0]->uid);
        $this->common_model->delete_data('table_students', 'student_id', $id);
        $this->common_model->delete_data('table_exam_assign', 'student_id', $id);
        $this->common_model->delete_data('table_exam_result', 'student_id', $id);
		$this->session->set_userdata('messages', array('msg' => 'Successfully Deleted'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
}
