<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Account extends CI_Controller 
{
	function __construct()
	{
        parent::__construct();
        if(!isset($this->session->userdata['user_logged_in']))
		{
			redirect(base_url().'login', 'refresh');
		}
		$this->load->model('front/common_model');
		$this->load->model('front/user_model');
	}
	
	public function index()
	{
		if($this->session->userdata('user_logged_in'))
		{
			redirect(base_url().'account/dashboard', 'refresh');
		}
		else
		{
			redirect(base_url().'login', 'refresh');
		}
	}

	public function logout()
	{
		$sess_array = array(
                        'admin_id' => '',
                        'rid' => '',
                        'admin_name' => '',
                        );
		$this->session->unset_userdata('user_logged_in', $sess_array);
		$this->session->set_userdata('user_messages', array('msg' => 'Successfully Logout'));
		redirect(base_url().'login', 'refresh');
	}
	
	public function dashboard()
	{
		if(isset($this->session->userdata['user_messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['user_messages']['msg'];
			$this->session->unset_userdata('user_messages', array('msg' => ''));
		}
		$uid = $this->session->userdata['user_logged_in']['admin_id'];
		if($this->session->userdata['user_logged_in']['rid'] == 3)
        {
			$uid = $this->session->userdata['user_logged_in']['admin_id'];
			$student = $this->common_model->get_data('table_students', 'uid', $uid);
            $course_id = $student[0]->course_id;
			$data['results_course'] = $this->common_model->get_data('table_courses', 'course_id', $course_id);
        }

		$data['total_course'] = $this->common_model->record_count('table_courses', '');
		$data['total_act'] = $this->common_model->record_count('table_acts', '');
		$data['total_student'] = $this->common_model->record_count('table_students', '');
		$data['total_paper'] = $this->common_model->record_count('table_papers', '');
		$data['meta_title'] = 'Dashboard';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/account/dashboard',$data);
	}
	
	public function password()
	{
		if ($this->input->post('submit')) 
		{
			$this->form_validation->set_rules('password','Current Password',  'trim|required|xss_clean|callback_oldpass_check');            
			$this->form_validation->set_rules('new_user_password','New Password', 'trim|required|xss_clean');
			$this->form_validation->set_rules('confirm_user_password', 'Confirm password', 'trim|required|xss_clean|matches[new_user_password]');
		
			if($this->form_validation->run() == TRUE) 
			{
				$user_id = $this->session->userdata['user_logged_in']['admin_id'];
				$password = md5($this->input->post('confirm_user_password'));
				$data = array( 'password' => $password);                   
				$this->common_model->update_data('table_users', 'uid', $user_id, $data);
				$data['message_display'] = 'Password updated successfully';                      
			}
		}                    
		$data['meta_title'] = 'Change Password';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/account/change_password',$data);  
	}
	
	public function oldpass_check($oldpass)
	{ 	
		$user_id = $this->session->userdata['user_logged_in']['admin_id']; 
		$result = $this->user_model->check_oldpassword('table_users', 'uid', 'password', $oldpass, $user_id);       
		if($result == 0)
		{
			$this->form_validation->set_message('oldpass_check', "%s doesn't match.");
			return FALSE ;  
		}
		else
		{
		 	return TRUE ;
		}             
	}
	
	public function profile()
	{
		$user_id = $this->session->userdata['user_logged_in']['admin_id'];
		if ($this->input->post('submit')) 
		{
			if($this->session->userdata['user_logged_in']['rid'] == 3)
        	{	
				$input_data2 = array(
					'name' => $this->input->post('name'),
					'email' => $this->input->post('email'),
					'phone' => $this->input->post('phone'),
					'address' => $this->input->post('address'),
					'username' => $this->input->post('username'),
					'modified' => date('d-m-Y h:i:s')
					);
					
				$this->common_model->update_data('table_students', 'uid', $user_id, $input_data2);
			}	
			$input_data = array(
						'name' => $this->input->post('name'),
						'email' => $this->input->post('email'),
						'username' => $this->input->post('username'),
						'modified' => date('d-m-Y h:i:s')
                        );
                        
			$this->common_model->update_data('table_users', 'uid', $user_id, $input_data);
			$data['message_display'] = 'Details successfully updated';
		}
		if(isset($this->session->userdata['user_messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['user_messages']['msg'];
			$this->session->unset_userdata('user_messages', array('msg' => ''));
		}

		if($this->session->userdata['user_logged_in']['rid'] == 3)
        {
			$data['result'] = $this->common_model->get_data('table_students', 'uid', $user_id);
        }
		else
		{
			$data['result'] = $this->common_model->get_data('table_users', 'uid', $user_id);
		}
		$data['meta_title'] = 'Profile';
		$data['meta_description'] = '';
		$data['meta_key'] = '';

		$this->load->view('front/account/edit_profile',$data);
	}

	public function interactive()
	{
		if(isset($this->session->userdata['user_messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['user_messages']['msg'];
			$this->session->unset_userdata('user_messages', array('msg' => ''));
		}

		$uid = $this->session->userdata['user_logged_in']['admin_id'];
		$student = $this->common_model->get_data('table_students', 'uid', $uid);
		$batch_id = $student[0]->batch_id;
		$data['results_batch'] = $this->common_model->get_data('table_batches', 'batch_id', $batch_id);

		$data['meta_title'] = 'Interactive Session';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/account/interactive',$data);
	}
	
}
