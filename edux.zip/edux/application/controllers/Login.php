<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('front/user_model');
	}
	
	public function index()
	{
		if($this->session->userdata('user_logged_in'))
		{
			redirect('account/dashboard', 'refresh');
		}
		if ($this->input->post('submit')) 
		{
			$data = array(
                    'username' => $this->input->post('username'),
                    'password' => md5($this->input->post('password'))
                    );
			$result = $this->user_model->login($data);
			if ($result != FALSE) 
			{
				$session_data = array(
                    'admin_id' => $result[0]->uid,
                    'rid' => $result[0]->rid,
                    'admin_name' => $result[0]->name,
                    );
				$this->session->set_userdata('user_logged_in', $session_data);
				redirect('account/dashboard', 'refresh');	
			} 
			else 
			{
				$data ['error_message'] = 'Invalid Username or Password';
			}
		}
		if(isset($this->session->userdata['user_messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['user_messages']['msg'];
			$this->session->unset_userdata('user_messages', array('msg' => ''));
		}
		$data['meta_title'] = 'Login';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/account/login',$data);
	}

}
