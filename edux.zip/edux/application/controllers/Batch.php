<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Batch extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('user_logged_in'))
		{
            redirect(base_url().'login', 'refresh');
        }
		$this->load->model('front/common_model');
	}
	
	public function index()
	{
		redirect(base_url().'batch/manage', 'refresh');
	}
	
	public function manage()
	{
		$total_row = $this->common_model->record_count('table_batches', '');
		$config['base_url'] = $this->config->base_url().'batch/manage/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 30;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
		
		$this->pagination->initialize($config);
		if($this->uri->segment(3))
		{
			$page = ($this->uri->segment(3)) ;
		}
		else
		{
			$page = 1;
		}
		$data['results'] = $this->common_model->fetch_data('table_batches', '', 'batch_id', 'DESC', $config['per_page'], $page);
		$data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}
		$data['meta_title'] = 'Manage Batch';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/batch/manage_batch',$data);
	}
	
	public function add()
	{
		if ($this->input->post('submit')) 
		{
            $err = 0;
            $batch_check = $this->common_model->get_list('table_batches', "batch_no='".$this->input->post('batch_no')."'");
            
            if($batch_check != FALSE)
            {
                $data['error_message'] = 'Batch No already exists. Please choose different one.';
                $err = 1;
            }
            
            if($err != 1)
            {
                $input_data = array(
                        'batch_no' => $this->input->post('batch_no'),
                        'start_date' => $this->input->post('start_date'),
                        'end_date' => $this->input->post('end_date'),
                        'batch_time' => $this->input->post('batch_time'),
						'google_meet' => $this->input->post('google_meet'),
                        'created' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->add_data('table_batches', $input_data);

                $this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
                redirect(base_url().'batch/manage', 'refresh');
            }
        }

		$data['meta_title'] = 'Add Batch';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/batch/add_batch',$data);
	}
	
	public function status()
	{
		$id = $this->uri->segment(3);
        $status = $this->uri->segment(4);
		$input_data = array(
					'status' => $status,
					);
        $this->common_model->update_data('table_batches', 'batch_id', $id, $input_data);
		$this->session->set_userdata('messages', array('msg' => 'Status Updated'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
	public function edit()
	{
        $id = $this->uri->segment(3);
        
        if ($this->input->post('submit')) 
		{
            $err = 0;
            $batch_check = $this->common_model->get_list('table_batches', "batch_no='".$this->input->post('batch_no')."' AND batch_id<>".$id."");
            
            if($batch_check != FALSE)
            {
                $data['error_message'] = 'Batch No already exists. Please choose different one.';
                $err = 1;
            }
            
            if($err != 1)
            {

                $input_data = array(
                        'batch_no' => $this->input->post('batch_no'),
                        'start_date' => $this->input->post('start_date'),
                        'end_date' => $this->input->post('end_date'),
                        'batch_time' => $this->input->post('batch_time'),
						'google_meet' => $this->input->post('google_meet'),
                        'modified' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->update_data('table_batches', 'batch_id', $id, $input_data);
                $this->session->set_userdata('messages', array('msg' => 'Details successfully updated'));
                redirect(base_url().'batch/manage', 'refresh');
            }
        }
        
        $data['result'] = $this->common_model->get_data('table_batches', 'batch_id', $id);
		$data['meta_title'] = 'Edit Batch';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/batch/edit_batch',$data);
	}
	
	public function view()
	{
        $id = $this->uri->segment(3);
		$data['result'] = $this->common_model->get_data('table_batches', 'batch_id', $id);
		$data['meta_title'] = 'View Batch';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/batch/view_batch',$data);
	}
	
	public function delete()
	{
        $id = $this->uri->segment(3);
        $this->common_model->delete_data('table_batches', 'batch_id', $id);
		$this->session->set_userdata('messages', array('msg' => 'Successfully Deleted'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
}
