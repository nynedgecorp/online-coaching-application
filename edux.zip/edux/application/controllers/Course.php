<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Course extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('user_logged_in'))
		{
            redirect(base_url().'login', 'refresh');
        }
		$this->load->model('front/common_model');
	}
	
	public function index()
	{
		redirect(base_url().'course/manage', 'refresh');
	}
	
	public function manage()
	{
		$total_row = $this->common_model->record_count('table_courses', '');
		$config['base_url'] = $this->config->base_url().'course/manage/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 30;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
		
		$this->pagination->initialize($config);
		if($this->uri->segment(3))
		{
			$page = ($this->uri->segment(3)) ;
		}
		else
		{
			$page = 1;
		}
		$data['results'] = $this->common_model->fetch_data('table_courses', '', 'course_id', 'DESC', $config['per_page'], $page);
		$data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}
		$data['meta_title'] = 'Manage Course';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/course/manage_course',$data);
	}
	
	public function add()
	{
		if ($this->input->post('submit')) 
		{
            $err = 0;
            $course_check = $this->common_model->get_list('table_courses', "name='".$this->input->post('name')."'");
            
            if($course_check != FALSE)
            {
                $data['error_message'] = 'Course name is already exists. Please choose different one.';
                $err = 1;
            }
            
            if($err != 1)
            {
                $input_data = array(
                        'name' => $this->input->post('name'),
						'overview' => $this->input->post('overview'),
						'status' => 1,
                        'created' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->add_data('table_courses', $input_data);

                $this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
                redirect(base_url().'course/manage', 'refresh');
            }
        }

		$data['meta_title'] = 'Add Course';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/course/add_course',$data);
	}
	
	public function status()
	{
		$id = $this->uri->segment(3);
        $status = $this->uri->segment(4);
		$input_data = array(
					'status' => $status,
					);
        $this->common_model->update_data('table_courses', 'course_id', $id, $input_data);
		$this->session->set_userdata('messages', array('msg' => 'Status Updated'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
	public function edit()
	{
        $id = $this->uri->segment(3);
        
        if ($this->input->post('submit')) 
		{
            $err = 0;
            $course_check = $this->common_model->get_list('table_courses', "name='".$this->input->post('name')."' AND course_id<>".$id."");
            
            if($course_check != FALSE)
            {
                $data['error_message'] = 'Course name is already exists. Please choose different one.';
                $err = 1;
            }
            
            if($err != 1)
            {

                $input_data = array(
                        'name' => $this->input->post('name'),
						'overview' => $this->input->post('overview'),
                        'modified' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->update_data('table_courses', 'course_id', $id, $input_data);
                $this->session->set_userdata('messages', array('msg' => 'Details successfully updated'));
                redirect(base_url().'course/manage', 'refresh');
            }
        }
        
        $data['result'] = $this->common_model->get_data('table_courses', 'course_id', $id);
		$data['meta_title'] = 'Edit Course';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/course/edit_course',$data);
	}
	
	public function view()
	{
        $id = $this->uri->segment(3);
		$data['result'] = $this->common_model->get_data('table_courses', 'course_id', $id);
		$data['meta_title'] = 'View Course';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/course/view_course',$data);
	}
	
	public function delete()
	{
        $id = $this->uri->segment(3);
        $this->common_model->delete_data('table_courses', 'course_id', $id);
		$this->session->set_userdata('messages', array('msg' => 'Successfully Deleted'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
}
