<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Practice_Exam extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('user_logged_in'))
		{
            redirect(base_url().'login', 'refresh');
        }
		$this->load->model('front/common_model');
	}
	
	public function index()
	{
		redirect(base_url().'practice_exam/manage', 'refresh');
	}
	
	public function manage()
	{
		$total_row = $this->common_model->record_count('table_acts', '');
		$config['base_url'] = $this->config->base_url().'practice_exam/manage/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 30;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
		
		$this->pagination->initialize($config);
		if($this->uri->segment(3))
		{
			$page = ($this->uri->segment(3)) ;
		}
		else
		{
			$page = 1;
        }
        if($this->session->userdata['user_logged_in']['rid'] == 3)
        {
			$uid = $this->session->userdata['user_logged_in']['admin_id'];
			$student = $this->common_model->get_data('table_students', 'uid', $uid);
            $condition = 'student_id='.$student[0]->student_id;
			$data['results'] = $this->common_model->fetch_data('table_practice_exam_assign', $condition, 'exam_assign_id', 'DESC', $config['per_page'], $page);
        }
        else
        {
		    $data['results'] = $this->common_model->fetch_data('table_acts', '', 'act_id', 'DESC', $config['per_page'], $page);
        }
        $data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}
		$data['meta_title'] = 'Manage Exam';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/manage_exam',$data);
	}

	public function manage_question()
	{
		$total_row = $this->common_model->record_count('table_practice_exam', 'act_id='.$this->uri->segment(3));
		$config['base_url'] = $this->config->base_url().'practice_exam/manage_question/'.$this->uri->segment(3).'/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 50;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
		
		$this->pagination->initialize($config);
		if($this->uri->segment(4))
		{
			$page = ($this->uri->segment(4)) ;
		}
		else
		{
			$page = 1;
		}
		
		$act_id = $this->uri->segment(3);
        
		$data['results'] = $this->common_model->fetch_data('table_practice_exam', 'act_id='.$act_id, 'exam_id', 'ASC', $config['per_page'], $page);
        $data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}
		$data['meta_title'] = 'Manage Question';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/manage_question',$data);
	}
	
	public function add_question()
	{
		if ($this->input->post('submit')) 
		{         
			$input_data = array(
					'act_id' => $this->uri->segment(3),
					'question' => $this->input->post('question'),
					'option_a' => $this->input->post('option_a'),
					'option_b' => $this->input->post('option_b'),
					'option_c' => $this->input->post('option_c'),
					//'option_d' => $this->input->post('option_d'),
					'answer' => $this->input->post('answer'),
					'created' => date('d-m-Y h:i:s')
					);   
							
			$this->common_model->add_data('table_practice_exam', $input_data);

			$this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
			redirect(base_url().'practice_exam/manage_question/'.$this->uri->segment(3), 'refresh');
		}
		
		$data['meta_title'] = 'Add Question';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/add_question',$data);
	}
	
	
	public function edit_question()
	{
        $id = $this->uri->segment(4);
        
        if ($this->input->post('submit')) 
		{
            $input_data = array(
				'question' => $this->input->post('question'),
				'option_a' => $this->input->post('option_a'),
				'option_b' => $this->input->post('option_b'),
				'option_c' => $this->input->post('option_c'),
				//'option_d' => $this->input->post('option_d'),
				'answer' => $this->input->post('answer'),
				'modified' => date('d-m-Y h:i:s')
				); 
                                
                $this->common_model->update_data('table_practice_exam', 'exam_id', $id, $input_data);
                $this->session->set_userdata('messages', array('msg' => 'Details successfully updated'));
                redirect(base_url().'practice_exam/manage_question/'.$this->uri->segment(3), 'refresh');
        }

        $data['result'] = $this->common_model->get_data('table_practice_exam', 'exam_id', $id);
		$data['meta_title'] = 'Edit Question';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/edit_question',$data);
	}
	
	public function view_question()
	{
        $id = $this->uri->segment(4);
		$data['result'] = $this->common_model->get_data('table_practice_exam', 'exam_id', $id);
		$data['meta_title'] = 'View Question';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/view_question',$data);
	}
	
	public function delete_question()
	{
        $id = $this->uri->segment(4);
    
        $this->common_model->delete_data('table_practice_exam', 'exam_id', $id);
		$this->session->set_userdata('messages', array('msg' => 'Successfully Deleted'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}

	public function assign()
	{
		if ($this->input->post('submit')) 
		{   
			$student_id = $_POST['student_id'];
			for($i = 0; $i < count($student_id); $i++)
			{     
				$input_data = array(
						'act_id' => $this->uri->segment(3),
						'student_id' => $student_id[$i],
						'created' => date('d-m-Y h:i:s')
						);   
				$assign = $this->common_model->get_list('table_practice_exam_assign', 'student_id='.$student_id[$i].' AND act_id ='.$this->uri->segment(3));		
				if($assign == FALSE)
				{		
					$this->common_model->add_data('table_practice_exam_assign', $input_data);
				}
			}

			$this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
			redirect(base_url().'practice_exam/manage', 'refresh');
		}

		$data['students'] = $this->common_model->get_data('table_students', 'status', 1);
		$data['meta_title'] = 'Assign Student';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/assign_student',$data);
	}

	public function start_test()
	{
		$test_result = $this->common_model->get_list('table_practice_exam_result', 'student_id='.$this->uri->segment(4).' AND act_id='.$this->uri->segment(3));
		if($test_result == TRUE)
		{
			redirect(base_url().'practice_exam/result/'.$this->uri->segment(3).'/'.$this->uri->segment(4), 'refresh');
		}
		if ($this->input->post('submit')) 
		{ 
			$questions = $this->common_model->get_data('table_practice_exam', 'act_id', $this->uri->segment(3));
			$i = 1; 
			foreach($questions as $question){
				if($this->input->post('answer_'.$i) == $question->answer)
				{
					$correct = 1;
				}
				else
				{
					$correct = 0;
				}
				$input_data = array(
						'student_id' => $this->uri->segment(4),
						'act_id' => $this->uri->segment(3),
						'exam_id' => $this->input->post('exam_id_'.$i),
						'answer' => $this->input->post('answer_'.$i),
						'correct' => $correct,
						'created' => date('d-m-Y h:i:s')
						);   
								
				$this->common_model->add_data('table_practice_exam_result', $input_data);
				$i++;
			}

			$this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
			redirect(base_url().'practice_exam/result/'.$this->uri->segment(3).'/'.$this->uri->segment(4), 'refresh');
		}
		
		$data['meta_title'] = 'Start Test';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/start_test',$data);
	}

	public function result()
	{
		$act_id = $this->uri->segment(3);
		$student_id = $this->uri->segment(4);
		$data['questions'] = $this->common_model->get_data('table_practice_exam', 'act_id', $act_id);
		$data['test_result'] = $this->common_model->get_list('table_practice_exam_result', 'student_id='.$this->uri->segment(4).' AND act_id='.$this->uri->segment(3));
		$data['meta_title'] = 'Result';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/view_result',$data);
	}

	public function manage_result()
	{
		$condition = 'act_id='.$this->uri->segment(3);
		$total_row = $this->common_model->record_count('table_practice_exam_assign', $condition);
		$config['base_url'] = $this->config->base_url().'practice_exam/manage_result/'.$this->uri->segment(3).'/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 50;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
		
		$this->pagination->initialize($config);
		if($this->uri->segment(4))
		{
			$page = ($this->uri->segment(4)) ;
		}
		else
		{
			$page = 1;
		}
		
		$act_id = $this->uri->segment(3);
        
		$data['results'] = $this->common_model->fetch_data('table_practice_exam_assign', 'act_id='.$act_id, 'exam_assign_id', 'DESC', $config['per_page'], $page);
        $data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}
		$data['meta_title'] = 'Manage Result';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/practice_exam/manage_result',$data);
	}
	
}
