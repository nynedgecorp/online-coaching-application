<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Act extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('user_logged_in'))
		{
            redirect(base_url().'login', 'refresh');
        }
		$this->load->model('front/common_model');
	}
	
	public function index()
	{
		redirect(base_url().'act/manage', 'refresh');
	}
	
	public function manage()
	{
		$total_row = $this->common_model->record_count('table_acts', '');
		$config['base_url'] = $this->config->base_url().'act/manage/';
		$config['total_rows'] = $total_row;
		$config['per_page'] = 30;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $total_row;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
		$config['reuse_query_string'] = TRUE;
		
		$this->pagination->initialize($config);
		if($this->uri->segment(3))
		{
			$page = ($this->uri->segment(3)) ;
		}
		else
		{
			$page = 1;
        }
        if($this->session->userdata['user_logged_in']['rid'] == 3)
        {
            $uid = $this->session->userdata['user_logged_in']['admin_id'];
            $student = $this->common_model->get_data('table_students', 'uid', $uid);
            $condition = 'phase_id='.$student[0]->phase_id.' AND course_id='.$student[0]->course_id;
            $data['results'] = $this->common_model->fetch_data('table_acts', $condition, 'act_id', 'DESC', $config['per_page'], $page);
            $data['phase_name'] = $this->common_model->get_data('table_phases', 'phase_id', $student[0]->phase_id);
			$data['course_name'] = $this->common_model->get_data('table_courses', 'course_id', $student[0]->course_id);
        }
        else
        {
			if(isset($_GET['course_id']) && $_GET['course_id'])
			{
				$data['results'] = $this->common_model->fetch_data('table_acts', 'course_id='.$_GET['course_id'], 'act_id', 'DESC', $config['per_page'], $page);
			}
			else
			{
				$data['results'] = $this->common_model->fetch_data('table_acts', '', 'act_id', 'DESC', $config['per_page'], $page);
			}
        }
        $data['total_rows'] = $total_row;
		$str_links = $this->pagination->create_links();
		$data['links'] = explode('&nbsp;',$str_links );
		if(isset($this->session->userdata['messages']['msg']))
		{
			$data['message_display'] = $this->session->userdata['messages']['msg'];
			$this->session->unset_userdata('messages', array('msg' => ''));
		}
		
		$data['courses'] = $this->common_model->get_data('table_courses', 'status', '1');
		$data['meta_title'] = 'Manage ACT';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/act/manage_act',$data);
	}
	
	public function add()
	{
		if ($this->input->post('submit')) 
		{
            $err = 0;
            $study_material = $bare_act = $format = '';

			if($_FILES['study_material']['name'][0] != '')
			{
				$config1['upload_path'] = './uploads/act/';
				$config1['allowed_types'] = 'pdf|doc|docx|ppt|pptx';
				$config1['overwrite'] = TRUE;
				$config1['encrypt_name'] = TRUE;

				$study_material_arr = array();
				$study_material_cnt = count($_FILES['study_material']['name']);
				for($i = 0; $i < $study_material_cnt; $i++)
				{
					$_FILES['userfile']['name']     = $_FILES['study_material']['name'][$i];
					$_FILES['userfile']['type']     = $_FILES['study_material']['type'][$i];
					$_FILES['userfile']['tmp_name'] = $_FILES['study_material']['tmp_name'][$i];
					$_FILES['userfile']['error']    = $_FILES['study_material']['error'][$i];
					$_FILES['userfile']['size']     = $_FILES['study_material']['size'][$i];

					
					$this->upload->initialize($config1);

					$this->upload->do_upload();
					$file_data1 = $this->upload->data();
					$study_material_arr[] = $file_data1['file_name'];
				}
				$study_material = implode(',',$study_material_arr);
			}

			if($_FILES['bare_act']['name'][0] != '')
			{
				$config2['upload_path'] = './uploads/act/';
				$config2['allowed_types'] = 'pdf|doc|docx|ppt|pptx';
				$config2['overwrite'] = TRUE;
				$config2['encrypt_name'] = TRUE;

				$bare_act_arr = array();
				$bare_act_cnt = count($_FILES['bare_act']['name']);
				for($j = 0; $j < $bare_act_cnt; $j++)
				{
					$_FILES['userfile']['name']     = $_FILES['bare_act']['name'][$j];
					$_FILES['userfile']['type']     = $_FILES['bare_act']['type'][$j];
					$_FILES['userfile']['tmp_name'] = $_FILES['bare_act']['tmp_name'][$j];
					$_FILES['userfile']['error']    = $_FILES['bare_act']['error'][$j];
					$_FILES['userfile']['size']     = $_FILES['bare_act']['size'][$j];

					
					$this->upload->initialize($config2);

					$this->upload->do_upload();
					$file_data2 = $this->upload->data();
					$bare_act_arr[] = $file_data2['file_name'];
				}
				$bare_act = implode(',',$bare_act_arr);
			}

			if($_FILES['format']['name'][0] != '')
			{
				$config3['upload_path'] = './uploads/act/';
				$config3['allowed_types'] = 'pdf|doc|docx|ppt|pptx';
				$config3['overwrite'] = TRUE;
				$config3['encrypt_name'] = TRUE;

				$format_arr = array();
				$format_cnt = count($_FILES['format']['name']);
				for($k = 0; $k < $format_cnt; $k++)
				{
					$_FILES['userfile']['name']     = $_FILES['format']['name'][$k];
					$_FILES['userfile']['type']     = $_FILES['format']['type'][$k];
					$_FILES['userfile']['tmp_name'] = $_FILES['format']['tmp_name'][$k];
					$_FILES['userfile']['error']    = $_FILES['format']['error'][$k];
					$_FILES['userfile']['size']     = $_FILES['format']['size'][$k];

					
					$this->upload->initialize($config3);

					$this->upload->do_upload();
					$file_data3 = $this->upload->data();
					$format_arr[] = $file_data3['file_name'];
				}
				$format = implode(',',$format_arr);
			}

			

            if($err != 1)
            {
                $input_data = array(
						'course_id' => $this->input->post('course_id'),
                        'phase_id' => $this->input->post('phase_id'),
                        'name' => $this->input->post('name'),
                        'description' => $this->input->post('description'),
                        'study_material' => $study_material,
                        'bare_act' => $bare_act,
                        'format' => $format,
                        'created' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->add_data('table_acts', $input_data);

                $this->session->set_userdata('messages', array('msg' => 'Details successfully added'));
                redirect(base_url().'act/manage', 'refresh');
            }
        }

		$data['courses'] = $this->common_model->get_data('table_courses', 'status', '1');
        $data['phases'] = $this->common_model->get_data('table_phases', 'status', '1');
		$data['meta_title'] = 'Add ACT';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/act/add_act',$data);
	}
	
	public function status()
	{
		$id = $this->uri->segment(3);
        $status = $this->uri->segment(4);
		$input_data = array(
					'status' => $status,
					);
        $this->common_model->update_data('table_acts', 'act_id', $id, $input_data);
		$this->session->set_userdata('messages', array('msg' => 'Status Updated'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
	public function edit()
	{
        $id = $this->uri->segment(3);

        $acts = $this->common_model->get_data('table_acts', 'act_id', $id);
        
        if ($this->input->post('submit')) 
		{
            $err = 0;
            
            $study_material = $bare_act = $format = '';
			$study_material1 = $bare_act1 = $format1 = '';

            if($_FILES['study_material']['name'][0] != '')
			{
				$config1['upload_path'] = './uploads/act/';
				$config1['allowed_types'] = 'pdf|doc|docx|ppt|pptx';
				$config1['overwrite'] = TRUE;
				$config1['encrypt_name'] = TRUE;

				$study_material_arr = array();
				$study_material_cnt = count($_FILES['study_material']['name']);
				for($i = 0; $i < $study_material_cnt; $i++)
				{
					$_FILES['userfile']['name']     = $_FILES['study_material']['name'][$i];
					$_FILES['userfile']['type']     = $_FILES['study_material']['type'][$i];
					$_FILES['userfile']['tmp_name'] = $_FILES['study_material']['tmp_name'][$i];
					$_FILES['userfile']['error']    = $_FILES['study_material']['error'][$i];
					$_FILES['userfile']['size']     = $_FILES['study_material']['size'][$i];

					
					$this->upload->initialize($config1);

					$this->upload->do_upload();
					$file_data1 = $this->upload->data();
					$study_material_arr[] = $file_data1['file_name'];
				}
				$study_material = implode(',',$study_material_arr);
			}
			if($this->input->post('study_material1') != '')
			{
				$study_material1 = implode(',',$this->input->post('study_material1'));
			}
			if($_FILES['study_material']['name'][0] != '')
			{
				$study_material = $study_material1.','.$study_material;
			}
			else
			{
				$study_material = $study_material1;
			}

			if($_FILES['bare_act']['name'][0] != '')
			{
				$config2['upload_path'] = './uploads/act/';
				$config2['allowed_types'] = 'pdf|doc|docx|ppt|pptx';
				$config2['overwrite'] = TRUE;
				$config2['encrypt_name'] = TRUE;

				$bare_act_arr = array();
				$bare_act_cnt = count($_FILES['bare_act']['name']);
				for($j = 0; $j < $bare_act_cnt; $j++)
				{
					$_FILES['userfile']['name']     = $_FILES['bare_act']['name'][$j];
					$_FILES['userfile']['type']     = $_FILES['bare_act']['type'][$j];
					$_FILES['userfile']['tmp_name'] = $_FILES['bare_act']['tmp_name'][$j];
					$_FILES['userfile']['error']    = $_FILES['bare_act']['error'][$j];
					$_FILES['userfile']['size']     = $_FILES['bare_act']['size'][$j];

					
					$this->upload->initialize($config2);

					$this->upload->do_upload();
					$file_data2 = $this->upload->data();
					$bare_act_arr[] = $file_data2['file_name'];
				}
				$bare_act = implode(',',$bare_act_arr);
			}
			if($this->input->post('bare_act1') != '')
			{
				$bare_act1 = implode(',',$this->input->post('bare_act1'));
			}
			if($_FILES['bare_act']['name'][0] != '')
			{
				$bare_act = $bare_act1.','.$bare_act;
			}
			else
			{
				$bare_act = $bare_act1;
			}

			if($_FILES['format']['name'][0] != '')
			{
				$config3['upload_path'] = './uploads/act/';
				$config3['allowed_types'] = 'pdf|doc|docx|ppt|pptx';
				$config3['overwrite'] = TRUE;
				$config3['encrypt_name'] = TRUE;

				$format_arr = array();
				$format_cnt = count($_FILES['format']['name']);
				for($k = 0; $k < $format_cnt; $k++)
				{
					$_FILES['userfile']['name']     = $_FILES['format']['name'][$k];
					$_FILES['userfile']['type']     = $_FILES['format']['type'][$k];
					$_FILES['userfile']['tmp_name'] = $_FILES['format']['tmp_name'][$k];
					$_FILES['userfile']['error']    = $_FILES['format']['error'][$k];
					$_FILES['userfile']['size']     = $_FILES['format']['size'][$k];

					
					$this->upload->initialize($config3);

					$this->upload->do_upload();
					$file_data3 = $this->upload->data();
					$format_arr[] = $file_data3['file_name'];
				}
				$format = implode(',',$format_arr);
			}
			if($this->input->post('format1') != '')
			{
				$format1 = implode(',',$this->input->post('format1'));
			}
			if($_FILES['format']['name'][0] != '')
			{
				$format = $format1.','.$format;
			}
			else
			{
				$format = $format1;
			}

            if($err != 1)
            {

                $input_data = array(
						'course_id' => $this->input->post('course_id'),
                        'phase_id' => $this->input->post('phase_id'),
                        'name' => $this->input->post('name'),
                        'description' => $this->input->post('description'),
                        'modified' => date('d-m-Y h:i:s')
                        ); 
                if($_FILES['study_material']['name'] != '')
                {		
                    $input_data['study_material'] = $study_material;
                }
                if($_FILES['bare_act']['name'] != '')
                {		
                    $input_data['bare_act'] = $bare_act;
                }
                if($_FILES['format']['name'] != '')
                {		
                    $input_data['format'] = $format;
                }           
                                
                $this->common_model->update_data('table_acts', 'act_id', $id, $input_data);
                $this->session->set_userdata('messages', array('msg' => 'Details successfully updated'));
                redirect(base_url().'act/manage', 'refresh');
            }
        }
        
		$data['courses'] = $this->common_model->get_data('table_courses', 'status', '1');
        $data['phases'] = $this->common_model->get_data('table_phases', 'status', '1');
        $data['result'] = $this->common_model->get_data('table_acts', 'act_id', $id);
		$data['meta_title'] = 'Edit ACT';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/act/edit_act',$data);
	}
	
	public function view()
	{
        $id = $this->uri->segment(3);
		$data['result'] = $this->common_model->get_data('table_acts', 'act_id', $id);
		$data['meta_title'] = 'View ACT';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/act/view_act',$data);
	}
	
	public function delete()
	{
        $id = $this->uri->segment(3);
        
        $acts = $this->common_model->get_data('table_acts', 'act_id', $id);

        if($acts[0]->study_material != '')
		{ 
			$study_material_arr = explode(',', $acts[0]->study_material);
			foreach($study_material_arr as $study_material)
			{
				unlink('uploads/act/'.$study_material); 
			}
		}
        if($acts[0]->bare_act != '')
		{ 
			$bare_act_arr = explode(',', $acts[0]->bare_act);
			foreach($bare_act_arr as $bare_act)
			{
				unlink('uploads/act/'.$bare_act); 
			}
		}
        if($acts[0]->format != '')
		{ 
			$format_arr = explode(',', $acts[0]->format);
			foreach($format_arr as $format)
			{
				unlink('uploads/act/'.$format); 
			}
		}
    
        $this->common_model->delete_data('table_acts', 'act_id', $id);
		$this->session->set_userdata('messages', array('msg' => 'Successfully Deleted'));
		redirect($_SERVER['HTTP_REFERER'], 'refresh');
	}
	
}
