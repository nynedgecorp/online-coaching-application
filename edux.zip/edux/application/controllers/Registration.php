<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Registration extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('front/common_model');
	}
	
	public function index()
	{
		if ($this->input->post('submit')) 
		{
            $err = $err1 = 0;
            $photo = '';
            $qualification_file = '';
            $email_check = $this->common_model->get_list('table_students', "email='".$this->input->post('email')."'");
            $username_check = $this->common_model->get_list('table_students', "username='".$this->input->post('phone')."'");
            
            
            if($email_check != FALSE)
            {
                $data['error_message'] = 'Email already exists. Please choose different one.';
                $err = 1;
            }
            if($username_check != FALSE)
            {
                $data['error_message'] = 'Phone already exists. Please choose different one.';
                $err = 1;
            }

            if($err != 1)
            {
                if($_FILES['photo']['name'] != '')
                {
                    $config1['upload_path'] = './uploads/student/';
                    $config1['allowed_types'] = 'jpg|jpeg|png|gif';
                    $config1['overwrite'] = TRUE;
                    $config1['encrypt_name'] = TRUE;
                    
                    if (!is_dir($config1['upload_path'])) {
                        mkdir($config1['upload_path'], 0777, TRUE);
                    }  
            
                    $this->upload->initialize($config1);
                    
                    if (!$this->upload->do_upload('photo') && $_FILES['photo']['name'] != '')
                    {
                        $data['error_message'] = $this->upload->display_errors();
                        $err1 = 1;
                    }
                    else
                    {
                        $file_data1 = $this->upload->data();
                        $photo = $file_data1['file_name'];
                        $err1 = 0;
                    }
                }

                if($_FILES['qualification_file']['name'] != '')
                {
                    $config2['upload_path'] = './uploads/student/';
                    $config2['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                    $config2['overwrite'] = TRUE;
                    $config2['encrypt_name'] = TRUE;
                    
                    if (!is_dir($config2['upload_path'])) {
                        mkdir($config2['upload_path'], 0777, TRUE);
                    }  
            
                    $this->upload->initialize($config2);
                    
                    if (!$this->upload->do_upload('qualification_file') && $_FILES['qualification_file']['name'] != '')
                    {
                        $data['error_message'] = $this->upload->display_errors();
                        $err1 = 1;
                    }
                    else
                    {
                        $file_data2 = $this->upload->data();
                        $qualification_file = $file_data2['file_name'];
                        $err1 = 0;
                    }
                }
            }

            if($err != 1 && $err1 != 1)
            {

                $input_user = array(
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('phone'),
                    'password' => md5($this->input->post('password')),
                    'rid' => 3,
                    'status' => 0,
                    'created' => date('d-m-Y h:i:s')
                    );
                
                $this->common_model->add_data('table_users', $input_user);    
                $last_id_arr = $this->common_model->get_last_id('table_users', 'uid');
                $last_id = $last_id_arr[0]->uid; 

                $input_data = array(
                        'uid' => $last_id,
                        'course_id' => $this->input->post('course_id'),
                        'name' => $this->input->post('name'),
                        'email' => $this->input->post('email'),
                        'phone' => $this->input->post('phone'),
                        'alternate_no' => $this->input->post('alternate_no'),
                        'qual_academic_1' => $this->input->post('qual_academic_1'),
                        'qual_division_1' => $this->input->post('qual_division_1'),
                        'qual_year_1' => $this->input->post('qual_year_1'),
                        'qual_school_1' => $this->input->post('qual_school_1'),
                        'qual_subject_1' => $this->input->post('qual_subject_1'),
                        'qual_academic_2' => $this->input->post('qual_academic_2'),
                        'qual_division_2' => $this->input->post('qual_division_2'),
                        'qual_year_2' => $this->input->post('qual_year_2'),
                        'qual_school_2' => $this->input->post('qual_school_2'),
                        'qual_subject_2' => $this->input->post('qual_subject_2'),
                        'qual_academic_3' => $this->input->post('qual_academic_3'),
                        'qual_division_3' => $this->input->post('qual_division_3'),
                        'qual_year_3' => $this->input->post('qual_year_3'),
                        'qual_school_3' => $this->input->post('qual_school_3'),
                        'qual_subject_3' => $this->input->post('qual_subject_3'),
                        'qual_academic_4' => $this->input->post('qual_academic_4'),
                        'qual_division_4' => $this->input->post('qual_division_4'),
                        'qual_year_4' => $this->input->post('qual_year_4'),
                        'qual_school_4' => $this->input->post('qual_school_4'),
                        'qual_subject_4' => $this->input->post('qual_subject_4'),
                        'qual_academic_5' => $this->input->post('qual_academic_5'),
                        'qual_division_5' => $this->input->post('qual_division_5'),
                        'qual_year_5' => $this->input->post('qual_year_5'),
                        'qual_school_5' => $this->input->post('qual_school_5'),
                        'qual_subject_5' => $this->input->post('qual_subject_5'),
                        'qual_academic_6' => $this->input->post('qual_academic_6'),
                        'qual_division_6' => $this->input->post('qual_division_6'),
                        'qual_year_6' => $this->input->post('qual_year_6'),
                        'qual_school_6' => $this->input->post('qual_school_6'),
                        'qual_subject_6' => $this->input->post('qual_subject_6'),
                        'qual_academic_7' => $this->input->post('qual_academic_7'),
                        'qual_division_7' => $this->input->post('qual_division_7'),
                        'qual_year_7' => $this->input->post('qual_year_7'),
                        'qual_school_7' => $this->input->post('qual_school_7'),
                        'qual_subject_7' => $this->input->post('qual_subject_7'),
                        'qualification' => $this->input->post('qualification'),
                        'qualification_file' => $qualification_file,
                        'address' => $this->input->post('address'),
                        'pin_code' => $this->input->post('pin_code'),
                        'gender' => $this->input->post('gender'),
                        'admission_date' => $this->input->post('admission_date'),
                        'dob' => $this->input->post('dob'),
                        'candidate_type' => $this->input->post('candidate_type'),
                        'photo' => $photo,
                        'username' => $this->input->post('phone'),
                        'payment_mode' => $this->input->post('payment_mode'),
                        'payment_no' => $this->input->post('payment_no'),
                        'payment_date' => $this->input->post('payment_date'),
                        'status' => 0,
                        'created' => date('d-m-Y h:i:s')
                        );   
                                
                $this->common_model->add_data('table_students', $input_data);

                $data['message_display'] = 'Details successfully added';
            }
        }

        $data['courses'] = $this->common_model->get_data('table_courses', 'status', '1');
		$data['meta_title'] = 'Registration';
		$data['meta_description'] = '';
		$data['meta_key'] = '';
		$this->load->view('front/student/student_registration',$data);
	}
	
}
