<?php $this->load->view('front/includes/header.php'); ?>
        <!-- .aside -->
        <?php $this->load->view('front/includes/nav.php'); ?>
        <!-- /.aside -->
        <section id="content">
          <section class="vbox">
            <section class="scrollable">
              <section class="hbox stretch">
                <aside class="col-lg-6 b-l no-padder">
                  <section class="vbox">
                    <section class="scrollable">
                      <div class="wrapper">
                        <section class="panel panel-default">
                          <h4 class="padder">View Question</h4>
                            <header class="panel-heading">
                                <a href="<?php echo base_url();?>account/dashboard" class="text-success">Dashboard</a> &nbsp; » &nbsp;<a href="<?php echo base_url();?>practice_exam/manage_question/<?php echo $this->uri->segment(3);?>" class="text-success">Manage Question</a> &nbsp; » &nbsp; View Question
                            </header>
                          <table class="table table-striped m-b-none" data-ride="datatables">
                            <thead>
                              <tr>
                                <th width="25%">Information</th>
                                <th>Details</th>
                              </tr>
                            </thead>
                            <tbody>
                                <tr>
                                	<td>Question:</td>
                                    <td><?php print $result[0]->question;?></td>
                                </tr>    
                                <tr>
                                	<td>Option A:</td>
                                    <td><?php print $result[0]->option_a;?></td>
                                </tr>
                                <tr>
                                	<td>Option B:</td>
                                    <td><?php print $result[0]->option_b;?></td>
                                </tr>
                                <tr>
                                	<td>Option C:</td>
                                    <td><?php print $result[0]->option_c;?></td>
                                </tr>
                                <tr>
                                	<td>Answer:</td>
                                    <td>Option <?php print $result[0]->answer;?></td>
                                </tr>   
                          	</tbody>
                          </table>
                          
                          <footer class="panel-footer bg-light lter">
                            <ul class="nav nav-pills nav-sm">
                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>practice_exam/manage_question/<?php echo $this->uri->segment(3);?>'" >Back to List</button></li>
                            </ul>
                          </footer>
                        </section>
                        
                      </div>
                    </section>
                  </section>              
                </aside>
              </section>
            </section>
          </section>
          <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen,open" data-target="#nav,html"></a>
        </section>
      </section>
    </section>
  </section>
  

<?php $this->load->view('front/includes/footer.php'); ?>

