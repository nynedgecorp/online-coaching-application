<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

        <!-- /.aside -->

        <div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page">View Results</li>
              
            </ol>
          </nav>
        </div>
       
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0">
  <h3 class="mb-0">View Results</h3>
</div>


                          <?php if($test_result == TRUE){?>

                          <?php

                            $total_question = $this->common_model->record_count('table_practice_exam', 'act_id='.$this->uri->segment(3));

                            $total_correct = $this->common_model->record_count('table_practice_exam_result', 'act_id='.$this->uri->segment(3).' AND student_id='.$this->uri->segment(4).' AND correct=1');

                            $total_marks = ($total_correct / $total_question) * 100;

                            $total_marks = round($total_marks, 2);

                          ?> 

                          <h3 class="text-primary">Your total score is <?php echo $total_marks;?>%</h3> 

                           <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                              <tr>

                                <th width="25%">Question</th>

                               

                                <th>Correct</th>

                              </tr>

                            </thead>

                            <tbody>

                              <?php 

                              foreach($questions as $question){

                                $result = $this->common_model->get_list('table_practice_exam_result', 'student_id='.$this->uri->segment(4).' AND act_id='.$this->uri->segment(3).' AND exam_id='.$question->exam_id);

                              ?>

                                <tr>

                                	<td><b><?php echo $question->question;?></b>
                                    
                                    <br />A.<?php echo $question->option_a;?>
                                      <br />B.<?php echo $question->option_b;?>
                                      <br />C.<?php echo $question->option_c;?> 
                                      <br /> <span class="badge badge-success">Your Answer Option <?php echo $question->answer;?> </span>
                                      <span class="badge badge-default">Correct Answer <?php if($result[0]->answer != ''){?> Option <?php echo $result[0]->answer;?> <?php } ?></span>
                                    
                                    </td>

                                 

                                  <?php if($result[0]->correct == '1'){?>

                                  <td><p class="text-success"><i class="ni ni-check-bold"></i></p></td>

                                  <?php } else {?>

                                  <td><p class="text-danger"><i class="ni ni-fat-remove"></i></p></td>

                                  <?php } ?>

                                </tr>

                              <?php } ?>     

                          	</tbody>

                          </table>

                          <?php }

                          else

                          {?>

                          <div class="col-md-12">

                            <p class="text-danger text-center">You have not taken the exam yet.</p>

                          </div>

                          <?php }?>

                          <footer class="panel-footer lter">

                            <ul class="nav nav-pills nav-sm">

                              <?php if($this->session->userdata['user_logged_in']['rid'] == 3){?>

                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>practice_exam/manage'" >Back to List</button></li>

                              <?php } else {?>

                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>practice_exam/manage_result/<?php echo $this->uri->segment(3);?>'" >Back to List</button></li>

                              <?php } ?>

                            </ul>

                          </footer>

                        
<?php $this->load->view('front/includes/footer.php'); ?>
