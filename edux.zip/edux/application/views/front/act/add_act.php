<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

        <!-- /.aside -->
        
    

<div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>act/manage" class="text-default">Manage Study Material</a>
              <li class="breadcrumb-item active" aria-current="page">Add Study Material</li>
            </ol>
          </nav>
        </div>
     
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0">
  <h3 class="mb-0">Add Study Material</h3>
</div>
<!-- Light table -->
        
        
        
        

                                <?php if (validation_errors()) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo validation_errors();?>

                                </div>

                                <?php } ?>

                                <?php if (isset($error_message)) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $error_message;?>

                                </div>

                                <?php } ?>

                                <?php if (isset($message_display)) {?>

                                <div class="alert alert-success background-success">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $message_display;?>

                                </div>

                                <?php } ?>  

                                <div class="col-md-6">

                                    <form role="form" id="ResAdd" name="theForm" method="post" enctype="multipart/form-data" onsubmit="return validate()" data-validate="parsley" >

                                        <div class="form-group">

                                            <label>Course:</label>

                                            <select name="course_id" class="form-control">

                                                <option value="">Select</option>

                                                <?php foreach($courses as $course){?>

                                                <option value="<?php echo $course->course_id;?>" <?php if($course->course_id == set_value('course_id')){?> selected <?php }?>><?php echo $course->name;?></option>

                                                <?php } ?>

                                            </select>

                                        </div>

                                        <div class="form-group">

                                            <label>Module:</label>

                                            <select name="phase_id" class="form-control">

                                                <option value="">Select</option>

                                                <?php foreach($phases as $phase){?>

                                                <option value="<?php echo $phase->phase_id;?>" <?php if($phase->phase_id == set_value('phase_id')){?> selected <?php }?>><?php echo $phase->name;?></option>

                                                <?php } ?>

                                            </select>

                                        </div>

                                        <div class="form-group">

                                            <label>Name:</label>

                                            <input type="text" name="name" class="form-control" data-required="true" value="<?php print set_value('name');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Description:</label>

                                            <textarea name="description" class="form-control" data-required="true" ><?php print set_value('description');?></textarea>

                                        </div>

                                        <div class="form-group">

                                            <label>Study Material:<br/><small class="text-success">PDF, DOCX, PPTX files allowed.</small></label>

                                            <input type="file" name="study_material[]" class="form-control" multiple>

                                        </div>

                                        <div class="form-group">

                                            <label>Attachment:<br/><small class="text-success">PDF, DOCX, PPTX allowed.</small></label>

                                            <input type="file" name="bare_act[]" class="form-control" multiple>

                                        </div>

                                        <div class="form-group">

                                            <label>Format:<br/><small class="text-success">PDF, DOCX, PPTX allowed.</small></label>

                                            <input type="file" name="format[]" class="form-control" multiple>

                                        </div>

                                        <div class="line line-dashed b-b line-lg pull-in"></div>



                                        <input type="submit" class="btn btn-md btn-success" name="submit" id="submit" value="Submit">

                                        <input name="btnBack" type="button" class="btn btn-md btn-default" value="Back to List" size="35" onclick="window.location.href = '<?php echo base_url();?>act/manage'" />

                                    </form>

                                </div>

                           





<?php $this->load->view('front/includes/footer.php'); ?>



<script>

    $('#ResAdd').submit(function(){

        $('#submit').val('Uploading...');

    });

</script>