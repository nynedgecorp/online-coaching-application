<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

     <div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page">View Study Material</li>
              
            </ol>
          </nav>
        </div>
       
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0">
  <h3 class="mb-0">View Study Material </h3>
</div>


       

                        
                          <table class="table table-striped m-b-none" data-ride="datatables">

                            <thead>

                              <tr>

                                <th width="25%">Information</th>

                                <th>Details</th>

                              </tr>

                            </thead>

                            <?php 

                              $phase = $this->common_model->get_data('table_phases', 'phase_id', $result[0]->phase_id);

                              $course = $this->common_model->get_data('table_courses', 'course_id', $result[0]->course_id);

                            ?>

                            <tbody>

                                <tr>

                                	<td>Course</td>

                                    <td><?php print $course[0]->name;?></td>

                                </tr>

                                <tr>

                                	<td>Module</td>

                                    <td><?php print $phase[0]->name;?></td>

                                </tr>

                                <tr>

                                	<td>Name:</td>

                                    <td><?php print $result[0]->name;?></td>

                                </tr>    

                                <tr>

                                	<td>Description:</td>

                                    <td><?php print $result[0]->description;?></td>

                                </tr>

                                <?php if($result[0]->study_material !== ''){?>

                                <tr>

                                	<td>Study Material:</td>

                                    <td>

                                    <?php 

                                        if($result[0]->study_material != '')

                                        {

                                            $study_material_arr = explode(',', $result[0]->study_material);

                                            $i = 1;

                                            foreach($study_material_arr as $study_material)

                                            {?>

                                                <a target="_blank" href="<?php print base_url();?>uploads/act/<?php print $study_material;?>" class="btn btn-sm m-sp-none btn-success">View File <?php echo $i;?></a>&nbsp;&nbsp;

                                    <?php $i++; } } ?>

                                    </td>

                                </tr>

                                <?php } ?>

                                <?php if($result[0]->bare_act !== ''){?>

                                <tr>

                                	<td>Attachment:</td>

                                    <td>

                                    <?php 

                                        if($result[0]->bare_act != '')

                                        {

                                            $bare_act_arr = explode(',', $result[0]->bare_act);

                                            $j = 1;

                                            foreach($bare_act_arr as $bare_act)

                                            {?>

                                                <a target="_blank" href="<?php print base_url();?>uploads/act/<?php print $bare_act;?>" class="btn btn-sm m-sp-none btn-success">View File <?php echo $j;?></a>&nbsp;&nbsp;

                                    <?php $j++; } } ?>

                                    </td>

                                </tr>

                                <?php } ?>

                                <?php if($result[0]->format !== ''){?>

                                <tr>

                                	<td>Format:</td>

                                    <td>

                                    <?php 

                                        if($result[0]->format != '')

                                        {

                                            $format_arr = explode(',', $result[0]->format);

                                            $k = 1;

                                            foreach($format_arr as $format)

                                            {?>

                                                <a target="_blank" href="<?php print base_url();?>uploads/act/<?php print $format;?>" class="btn btn-sm m-sp-none btn-success">View File <?php echo $k;?></a>&nbsp;&nbsp;

                                    <?php $k++; } } ?>

                                    </td>

                                </tr>   

                                <?php } ?>

                          	</tbody>

                          </table>

                          

                          <footer class="panel-footer lter">

                            <ul class="nav nav-pills nav-sm">

                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>act/manage'" >Back to List</button></li>

                            </ul>

                          </footer>


                    
<?php $this->load->view('front/includes/footer.php'); ?>



