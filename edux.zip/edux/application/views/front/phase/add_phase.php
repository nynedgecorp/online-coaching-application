<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

     
      <!-- /.aside -->
<div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page">Add a Module</li>
              
            </ol>
          </nav>
        </div>
       
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0">
  <h3 class="mb-0">Add a Module</h3>
</div>


                                <?php if (validation_errors()) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo validation_errors();?>

                                </div>

                                <?php } ?>

                                <?php if (isset($error_message)) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $error_message;?>

                                </div>

                                <?php } ?>

                                <?php if (isset($message_display)) {?>

                                <div class="alert alert-success background-success">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $message_display;?>

                                </div>

                                <?php } ?>  

                                <div class="col-md-6">

                                    <form role="form" id="ResAdd" name="theForm" method="post" enctype="multipart/form-data" onsubmit="return validate()" data-validate="parsley" >

                                        <div class="form-group">

                                            <label>Module Name:</label>

                                            <input type="text" name="name" class="form-control" data-required="true" value="<?php print set_value('name');?>">

                                        </div>

                                        <div class="line line-dashed b-b line-lg pull-in"></div>



                                        <input type="submit" class="btn btn-md btn-success" name="submit" id="submit" value="Submit">

                                        <input name="btnBack" type="button" class="btn btn-md btn-default" value="Back to List" size="35" onclick="window.location.href = '<?php echo base_url();?>phase/manage'" />

                                    </form>

                                </div>

                            </section>




<?php $this->load->view('front/includes/footer.php'); ?>

