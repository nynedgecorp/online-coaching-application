<?php $this->load->view('front/includes/header.php'); ?>

<!-- .aside -->

<?php $this->load->view('front/includes/nav.php'); ?>

<div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="#" class="text-default">Interactive Session</a></li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
  <div class="row">
    <div class="col">
      <div class="card"> 
        <!-- Card header -->
        <div class="card-header border-0">
          <h3 class="mb-0">Interactive Session </h3>
        </div>

      <?php if (isset($error_message)) {?>
      <div class="alert alert-danger background-danger">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i class="icofont icofont-close-line-circled text-white"></i> </button>
        <?php echo $error_message;?> 
      <?php } ?>
      <?php if (isset($message_display)) {?>
      <div class="alert alert-success background-success">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i class="icofont icofont-close-line-circled text-white"></i> </button>
        <?php echo $message_display;?>
      <?php } ?>
      <table class="table align-items-center table-flush">
        <thead class="thead-light">
          <tr>
            <th>Platform</th>
            <th>Time</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Google Meet</td>
            <td><?php echo $results_batch[0]->batch_time;?></td>
            <td><a class="badge badge-pill badge-default"" href="<?php echo $results_batch[0]->google_meet;?>" target="_blank"> Join Now<?php /*?><?php echo $results_batch[0]->google_meet;?><?php */?></a></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $this->load->view('front/includes/footer.php'); ?>
