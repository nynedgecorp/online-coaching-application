<?php $this->load->view('front/includes/header.php'); ?>

<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary py-7 py-lg-8 pt-lg-9">
      <div class="container">
        <div class="header-body text-center mb-7">
          <div class="row justify-content-center">
            <div class="col-xl-5 col-lg-6 col-md-8 px-5">
              <h1 class="text-white">Welcome!</h1>
              <p class="text-lead text-white">Your Extensive e-Learning Applicationn.</p>
            </div>
          </div>
        </div>
      </div>
      
    </div>
 <div class="container mt--8 pb-5">
      <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
          <div class="card bg-secondary border-0 mb-0">
            <?php if (isset($error_message)) {?>

        <div class="alert alert-danger background-danger">

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                <i class="icofont icofont-close-line-circled text-white"></i>

            </button>

            <?php echo $error_message;?>

        </div>

      <?php } ?>
      
      
      <?php if (isset($message_display)) {?>

        <div class="alert alert-success background-success">

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                <i class="icofont icofont-close-line-circled text-white"></i>

            </button>

            <?php echo $message_display;?>

        </div>

       <?php } ?>           
            <div class="card-body px-lg-5 py-lg-5">
              <div class="text-center text-muted mb-4">
                <small>Or sign in with credentials</small>
              </div>
            <form name="loginform" id="loginform"  method="post">
                <div class="form-group mb-3">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                    </div>
                    <input type="text"  name="username"  id="username" placeholder="User ID" class="form-control">

                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                    </div>
                    
                      <input type="password" name="password" id="password" placeholder="Password" class="form-control">
                  </div>
                </div>
                
                <div class="text-center">
                 
                    <input type="submit" class="btn btn-primary my-4" value="Sign in" name="submit">
                </div>
              </form>
            </div>
          </div>
         
        </div>
      </div>
    </div>
  </div>



 <script>

 	$(document).ready(function() {

        $('body').addClass('bg-dark');

    });

 </script>

<?php $this->load->view('front/includes/footer.php'); ?>