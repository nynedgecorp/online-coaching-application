<?php $this->load->view('front/includes/header.php'); ?>
        <!-- .aside -->
        <?php $this->load->view('front/includes/nav.php'); ?>
        <!-- /.aside -->
        <section id="content">
          <section class="vbox">
            <section class="scrollable">
              <section class="hbox stretch">
                <aside class="col-lg-6 b-l no-padder">
                  <section class="vbox">
                    <section class="scrollable">
                      <div class="wrapper">
                        <section class="panel panel-default">
                          <h4 class="padder">View Paper</h4>
                            <header class="panel-heading">
                                <a href="<?php echo base_url();?>account/dashboard" class="text-success">Dashboard</a> &nbsp; » &nbsp;<a href="<?php echo base_url();?>paper/manage" class="text-success">Manage Paper</a> &nbsp; » &nbsp; View Paper
                            </header>
                          <table class="table table-striped m-b-none" data-ride="datatables">
                            <thead>
                              <tr>
                                <th width="25%">Information</th>
                                <th>Details</th>
                              </tr>
                            </thead>
                            
                            <tbody>
                                <tr>
                                	<td>Paper Name</td>
                                    <td><?php print $result[0]->name;?></td>
                                </tr>  
                          	</tbody>
                          </table>
                          
                          <footer class="panel-footer bg-light lter">
                            <ul class="nav nav-pills nav-sm">
                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>paper/manage'" >Back to List</button></li>
                            </ul>
                          </footer>
                        </section>
                        
                      </div>
                    </section>
                  </section>              
                </aside>
              </section>
            </section>
          </section>
          <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen,open" data-target="#nav,html"></a>
        </section>
      </section>
    </section>
  </section>
  

<?php $this->load->view('front/includes/footer.php'); ?>

