<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

      <div class="main-content" id="panel">
   <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                 <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"> Instructors</li>
              
            </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
              <a href="<?php echo base_url();?>employee/add"" class="btn btn-md btn-neutral">Add</a>
              
            </div>
          </div>
        </div>
      </div>
    </div>

       <div class="container-fluid mt--6">
      <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
             
            </div>

                <?php if (isset($error_message)) {?>

                <div class="alert alert-danger background-danger">

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                        <i class="icofont icofont-close-line-circled text-white"></i>

                    </button>

                    <?php echo $error_message;?>

      

                <?php } ?>

                <?php if (isset($message_display)) {?>

                <div class="alert alert-success background-success">

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                        <i class="icofont icofont-close-line-circled text-white"></i>

                    </button>

                    <?php echo $message_display;?>

       

                <?php } ?>

              
             <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">

                      <tr>

                        <th class="hidden-xs" width="20">#</th>

                        <th>Name</th>

                        <th>Email</th>

                        <th>Phone</th>

                        <th width="200">Status</th>

                        <th width="200">Action</th>

                      </tr>

                    </thead>

                    <tbody>

                    

                    <?php if($total_rows > 0 && $results == TRUE){

                        $page = $this->uri->segment(3);	

                        $count = ($page > 0) ? (($page - 1)*30 + 1) : 1;?>

                        <?php foreach($results as $row) {

                        if($row->status == '' || $row->status == 0)

                        {

                            $status = 1 ;

                            $pic = "<img src=\"".base_url()."assets/front/images/status-off.png\"  border=\"0\" />";

                        }

                        else 

                        {  

                            $status = 0 ; 

                            $pic = "<img src=\"".base_url()."assets/front/images/status-on.png\"  border=\"0\" />";

                        }

					?>

                    <tr>

                        <td class="hidden-xs"><?php echo $count; ?></td>

                        <td><?php print $row->name;?> </td>

                        <td><?php print $row->email;?></td>

                        <td><?php print $row->phone;?></td>

                        <td><a href="<?php echo base_url();?>employee/status/<?php echo $row->employee_id;?>/<?php echo $status;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Change Status" ><?php echo $pic;?></a></td>

                        <td>

                            <a href="<?php echo base_url();?>employee/delete/<?php echo $row->employee_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete" class="btn btn-sm m-sp-none btn-danger" id="delete"><i class="ni ni-fat-remove"></i></a>

                            <a href="<?php echo base_url();?>employee/edit/<?php echo $row->employee_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" class="btn btn-sm m-sp-none btn-warning"><i class="fa fa-wrench"></i></a>

                            <a href="<?php echo base_url();?>employee/view/<?php echo $row->employee_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"class="btn btn-sm m-sp-none btn-primary"><i class="fa fa-eye"></i></a>

                        </td>  

                    </tr>

					<?php $count++; } 

                    }else { ?> 

                    <tr><td colspan="6" style="text-align:center;color:#f00;">No Records Found &nbsp;!</td></tr>

                    <?php } ?>

                        </tbody>

                    </table>

                    <ul class="pagi">

                        <?php foreach ($links as $link) 

                        {

                        echo "<li>". $link."</li>";

                        } ?>

                    </ul>

                </div>

              

<?php $this->load->view('front/includes/footer.php'); ?>
