<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

        <!-- /.aside -->

       
     <div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page">View Batch</li>
              
            </ol>
          </nav>
        </div>
       
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0">
  <h3 class="mb-0">View a Batch</h3>
</div>

                          <table class="table table-striped m-b-none" data-ride="datatables">

                            <thead>

                              <tr>

                                <th width="25%">Information</th>

                                <th>Details</th>

                              </tr>

                            </thead>

                            

                            <tbody>

                                <tr>

                                	<td>Batch No</td>

                                    <td><?php print $result[0]->batch_no;?></td>

                                </tr>

                                <tr>

                                	<td>Start Date:</td>

                                    <td><?php print $result[0]->start_date;?></td>

                                </tr>    

                                <tr>

                                	<td>End Date:</td>

                                    <td><?php print $result[0]->end_date;?></td>

                                </tr> 

                                <tr>

                                	<td>Time</td>

                                    <td><span class="badge badge-pill badge-default"><?php print $result[0]->batch_time;?></span></td>

                                </tr>

                                <tr>

                                	<td>Google Meet Link:</td>

                                    <td><a href="<?php print $result[0]->google_meet;?>"><?php print $result[0]->google_meet;?></a></td>

                                </tr>   

                          	</tbody>

                          </table>

                          

                          <footer class="panel-footer lter">

                            <ul class="nav nav-pills nav-sm">

                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>batch/manage'" >Back to List</button></li>

                            </ul>

                          </footer>

                        
<?php $this->load->view('front/includes/footer.php'); ?>
