<?php $this->load->view('front/includes/header.php'); ?>
        <!-- .aside -->
        <?php $this->load->view('front/includes/nav.php'); ?>
        <!-- /.aside -->
        <section id="content">
          <section class="vbox">
            <section class="scrollable padder">
              <div class="m-b-md">
                <h3 class="m-b-none">Results</h3>   
              </div>
              
              <section class="panel panel-default">
                <header class="panel-heading">
                  <a href="<?php echo base_url();?>account/dashboard" class="text-success">Dashboard</a> &nbsp; » &nbsp; Manage Result
                </header>
                <?php if (isset($error_message)) {?>
                <div class="alert alert-danger background-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="icofont icofont-close-line-circled text-white"></i>
                    </button>
                    <?php echo $error_message;?>
                </div>
                <?php } ?>
                <?php if (isset($message_display)) {?>
                <div class="alert alert-success background-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="icofont icofont-close-line-circled text-white"></i>
                    </button>
                    <?php echo $message_display;?>
                </div>
                <?php } ?>
              
                <div class="table-responsive">
                  <table class="table table-striped b-t b-light">
                    <thead>
                      <tr>
                        <th class="hidden-xs" width="20">#</th>
                        <th>Student Name</th>
                        <th width="200">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                    <?php if($total_rows > 0 && $results == TRUE){
                        $page = $this->uri->segment(4);	
                        $count = ($page > 0) ? (($page - 1)*50 + 1) : 1;?>
                        <?php foreach($results as $row) {
                            $student = $this->common_model->get_data('table_students', 'student_id', $row->student_id);
                          ?>
                      <tr>
                        <td class="hidden-xs"><?php echo $count; ?></td>
                        <td><?php print $student[0]->name;?> </td>
                        <td>
                            <a href="<?php echo base_url();?>exam/result/<?php echo $this->uri->segment(3);?>/<?php echo $row->student_id;?>" data-toggle="tooltip" data-placement="bottom" title="View Result" data-original-title="View Result"class="btn btn-sm m-sp-none btn-primary"><i class="fa fa-eye"></i></a>
                        </td>  
                    </tr>
					          <?php $count++; } 
                    }else { ?> 
                    <tr><td colspan="3" style="text-align:center;color:#f00;">No Records Found &nbsp;!</td></tr>
                    <?php } ?>
                        </tbody>
                    </table>
                    <ul class="pagi">
                        <?php foreach ($links as $link) 
                        {
                        echo "<li>". $link."</li>";
                        } ?>
                    </ul>
                </div>
              </section>
            </section>
          </section>
          <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen,open" data-target="#nav,html"></a>
        </section>
      </section>
    </section>
  </section>
  
<?php $this->load->view('front/includes/footer.php'); ?>


