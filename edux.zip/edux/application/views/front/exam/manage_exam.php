<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

        <div class="main-content" id="panel">
   <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                 <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"> Manage Final Exam</li>
              
            </ol>
              </nav>
            </div>
           
          </div>
        </div>
      </div>
    </div>

       <div class="container-fluid mt--6">
      <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
             
            </div>
            
            

        
                <?php if (isset($error_message)) {?>

                <div class="alert alert-danger background-danger">

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                        <i class="icofont icofont-close-line-circled text-white"></i>

                    </button>

                    <?php echo $error_message;?>

                </div>

                <?php } ?>

                <?php if (isset($message_display)) {?>

                <div class="alert alert-success background-success">

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                        <i class="icofont icofont-close-line-circled text-white"></i>

                    </button>

                    <?php echo $message_display;?>

                </div>

                <?php } ?>



               <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">

                      <tr>

                        <th class="hidden-xs" width="20">#</th>

                        <th>Name</th>

                        <th width="200">Action</th>

                      </tr>

                    </thead>

                    <tbody>

                    <?php if($this->session->userdata['user_logged_in']['rid'] == 3)

                    {?>

                      <?php if($results == TRUE){

                          $uid = $this->session->userdata['user_logged_in']['admin_id'];

                          $student = $this->common_model->get_data('table_students', 'uid', $uid);

                          $page = $this->uri->segment(3);	

                          $count = ($page > 0) ? (($page - 1)*30 + 1) : 1;?>

                          <?php foreach($results as $row) {

                            $papers = $this->common_model->get_data('table_papers', 'paper_id', $row->paper_id);

                            $test_result = $this->common_model->get_list('table_exam_result', 'student_id='.$student[0]->student_id.' AND paper_id='.$row->paper_id);  

                      ?>

                      <tr>

                          <td class="hidden-xs"><?php echo $count; ?></td>

                          <td><?php print $papers[0]->name;?> </td>

                          <td>

                              <?php if($test_result == FALSE){?>

                              <a href="<?php echo base_url();?>exam/start_test/<?php echo $row->paper_id;?>/<?php echo $student[0]->student_id;?>" data-toggle="tooltip" data-placement="bottom" title="Start Test" data-original-title="Start Test" class="btn btn-sm m-sp-none btn-success"><i class="fa fa-plus"></i></a>

                              <?php } ?>

                              <?php if($test_result == TRUE){?>

                              <a href="<?php echo base_url();?>exam/result/<?php echo $row->paper_id;?>/<?php echo $student[0]->student_id;?>" data-toggle="tooltip" data-placement="bottom" title="Result" data-original-title="Result" class="btn btn-sm m-sp-none btn-warning"><i class="fa fa-eye"></i></a>

                              <?php } ?>  

                          </td>  

                      </tr>

                      <?php $count++; } 

                      }else { ?> 

                      <tr><td colspan="3" style="text-align:center;color:#f00;">No Records Found &nbsp;!</td></tr>

                      <?php } ?>

                          </tbody>

                      </table>

                    <?php } 

                    else {?>

                      <?php if($total_rows > 0 && $results == TRUE){

                          $page = $this->uri->segment(3);	

                          $count = ($page > 0) ? (($page - 1)*30 + 1) : 1;?>

                          <?php foreach($results as $row) {

                      ?>

                      <tr>

                          <td class="hidden-xs"><?php echo $count; ?></td>

                          <td><?php print $row->name;?> </td>

                          <td>

                              <a href="<?php echo base_url();?>exam/add_question/<?php echo $row->paper_id;?>" data-toggle="tooltip" data-placement="bottom" title="Add Question" data-original-title="Add Question" class="btn btn-sm m-sp-none btn-success"><i class="fa fa-plus"></i></a>

                              <a href="<?php echo base_url();?>exam/manage_question/<?php echo $row->paper_id;?>" data-toggle="tooltip" data-placement="bottom" title="Manage Question" data-original-title="Manage Question" class="btn btn-sm m-sp-none btn-warning"><i class="fa fa-eye"></i></a>

                              <a href="<?php echo base_url();?>exam/assign/<?php echo $row->paper_id;?>" data-toggle="tooltip" data-placement="bottom" title="Assign" data-original-title="Assign"class="btn btn-sm m-sp-none btn-primary"><i class="fa fa-check"></i></a>

                              <a href="<?php echo base_url();?>exam/manage_result/<?php echo $row->paper_id;?>" data-toggle="tooltip" data-placement="bottom" title="Result" data-original-title="Result"class="btn btn-sm m-sp-none btn-primary"><i class="fa fa-list-alt"></i></a>

                          </td>  

                      </tr>

                      <?php $count++; } 

                      }else { ?> 

                      <tr><td colspan="3" style="text-align:center;color:#f00;">No Records Found &nbsp;!</td></tr>

                      <?php } ?>

                          </tbody>

                      </table>

                      <?php } ?>  

                    <ul class="pagi">

                        <?php foreach ($links as $link) 

                        {

                        echo "<li>". $link."</li>";

                        } ?>

                    </ul>

                </div>
  

<?php $this->load->view('front/includes/footer.php'); ?>





