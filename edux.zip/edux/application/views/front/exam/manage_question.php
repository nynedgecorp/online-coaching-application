<?php $this->load->view('front/includes/header.php'); ?>

<!-- .aside -->

<?php $this->load->view('front/includes/nav.php'); ?>

<div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"> Manage Final Exam Questions</li>
            </ol>
          </nav>
        </div>
        <div class="col-lg-6 col-5 text-right"> <a href="<?php echo base_url();?>exam/add_question/<?php echo $this->uri->segment(3);?>"" class="btn btn-md btn-neutral">Add</a> </div>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0"> </div>
<?php if (isset($error_message)) {?>
<div class="alert alert-danger background-danger">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i class="icofont icofont-close-line-circled text-white"></i> </button>
<?php echo $error_message;?>
<?php } ?>
<?php if (isset($message_display)) {?>
<div class="alert alert-success background-success">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i class="icofont icofont-close-line-circled text-white"></i> </button>
<?php echo $message_display;?>
<?php } ?>
<?php if($total_rows > 0 && $results == TRUE){

                        $page = $this->uri->segment(4);	

                        $count = ($page > 0) ? (($page - 1)*50 + 1) : 1;?>
<?php foreach($results as $row) {?>
<div style="col-md-4">
  <div class="card card-stats"> 
    
    <!-- Card body -->
    <div class="card-body">
      <div class="row">
        <div class="col">
          <h5 class="btn btn-primary btn-sm"><?php echo $count; ?></h5>
          <span class="h3 font-weight-bold mb-0"><?php print $row->question;?></span> </div>
        <div class="col-auto">
          <div class="icon icon-shape bg-orange text-white rounded-circle shadow"> <i class="ni ni-chart-pie-35"></i> </div>
        </div>
      </div>
      <p class="mt-3 mb-0 text-sm"> 
      <span class="badge badge-primary"><?php print $row->option_a;?></span> 
      <span class="badge badge-primary"><?php print $row->option_b;?></span> 
      <span class="badge badge-primary"><?php print $row->option_c;?></span> 
      <span class="badge badge-success">Answer : <?php print $row->answer;?> </span></p>
       <p style="margin-bottom:10px;"> <a href="<?php echo base_url();?>exam/delete_question/<?php echo $this->uri->segment(3);?>/<?php echo $row->exam_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete" class="btn btn-sm m-sp-none btn-danger" id="delete"><i class="ni ni-fat-remove"></i></a> <a href="<?php echo base_url();?>exam/edit_question/<?php echo $this->uri->segment(3);?>/<?php echo $row->exam_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" class="btn btn-sm m-sp-none btn-warning"><i class="fa fa-wrench"></i></a> <a href="<?php echo base_url();?>exam/view_question/<?php echo $this->uri->segment(3);?>/<?php echo $row->exam_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"class="btn btn-sm m-sp-none btn-primary"><i class="fa fa-eye"></i></a> </p>
    </div>
  </div>
</div>
<?php $count++; } 

                    }else { ?>
<tr>
  <td colspan="7" style="text-align:center;color:#f00;">No Records Found &nbsp;!</td>
</tr>
<?php } ?>
<?php $this->load->view('front/includes/footer.php'); ?>
