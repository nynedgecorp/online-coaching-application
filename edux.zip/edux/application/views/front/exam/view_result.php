<?php $this->load->view('front/includes/header.php'); ?>
        <!-- .aside -->
        <?php $this->load->view('front/includes/nav.php'); ?>
        <!-- /.aside -->
        <section id="content">
          <section class="vbox">
            <section class="scrollable">
              <section class="hbox stretch">
                <aside class="col-lg-6 b-l no-padder">
                  <section class="vbox">
                    <section class="scrollable">
                      <div class="wrapper">
                        <section class="panel panel-default">
                          <h4 class="padder">Result</h4>
                            <header class="panel-heading">
                                <a href="<?php echo base_url();?>account/dashboard" class="text-success">Dashboard</a> &nbsp; » &nbsp;<a href="<?php echo base_url();?>exam/manage" class="text-success">Manage Exam</a> &nbsp; » &nbsp; Result
                            </header>
                            <?php 
                              if(isset($_SESSION['exam_end_time']))
                              {
                                unset($_SESSION['exam_end_time']);
                              }
                            ?>
                          <?php if($test_result == TRUE){?>
                          <?php
                            $total_question = $this->common_model->record_count('table_exam', 'paper_id='.$this->uri->segment(3));
                            $total_correct = $this->common_model->record_count('table_exam_result', 'paper_id='.$this->uri->segment(3).' AND student_id='.$this->uri->segment(4).' AND correct=1');
                            $total_marks = ($total_correct / $total_question) * 100;
                            $total_marks = round($total_marks, 2);
                            
                          ?> 
                          <?php if($this->session->userdata['user_logged_in']['rid'] == 3)
                              {?>
                              <h3 class="text-primary">Thank you for taking the test.</h3>
                          <?php } 
                          else {?>    
                          <h3 class="text-primary">Your total score is <?php echo $total_marks;?>%</h3> 
                          <table class="table table-striped m-b-none" data-ride="datatables">
                            <thead>
                              <tr>
                                <th width="25%">Question</th>
                                <th>Option A</th>
                                <th>Option B</th>
                                <th>Option C</th>
                                <th>Correct Answer</th>
                                <th>Your Answer</th>
                                <th>Correct</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php 
                              foreach($questions as $question){
                                $result = $this->common_model->get_list('table_exam_result', 'student_id='.$this->uri->segment(4).' AND paper_id='.$this->uri->segment(3).' AND exam_id='.$question->exam_id);
                              ?>
                                <tr>
                                  <td><?php echo $question->question;?></td>
                                  <td><?php echo $question->option_a;?></td>
                                  <td><?php echo $question->option_b;?></td>
                                  <td><?php echo $question->option_c;?></td>
                                  <td>Option <?php echo $question->answer;?></td>
                                  <td><?php if($result[0]->answer != ''){?> Option <?php echo $result[0]->answer;?> <?php } ?></td>
                                  <?php if($result[0]->correct == '1'){?>
                                  <td><p class="text-success">Yes</p></td>
                                  <?php } else {?>
                                  <td><p class="text-danger">No</p></td>
                                  <?php } ?>
                                </tr>
                              <?php } ?>     
                          	</tbody>
                          </table>
                          <?php }
                          }
                          else
                          {?>
                          <div class="col-md-12">
                            <p class="text-danger text-center">You have not taken the exam yet.</p>
                          </div>
                          <?php }?>
                          <footer class="panel-footer bg-light lter">
                            <ul class="nav nav-pills nav-sm">
                              <?php if($this->session->userdata['user_logged_in']['rid'] == 3){?>
                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>exam/manage'" >Back to List</button></li>
                              <?php } else {?>
                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>exam/manage_result/<?php echo $this->uri->segment(3);?>'" >Back to List</button></li>
                              <?php } ?>
                            </ul>
                          </footer>
                        </section>
                        
                      </div>
                    </section>
                  </section>              
                </aside>
              </section>
            </section>
          </section>
          <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen,open" data-target="#nav,html"></a>
        </section>
      </section>
    </section>
  </section>
  

<?php $this->load->view('front/includes/footer.php'); ?>

