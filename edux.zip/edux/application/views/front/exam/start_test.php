<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

        <!-- /.aside -->

      
      <div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page">Start Test</li>
              
            </ol>
          </nav>
        </div>
       
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0">
  <h3 class="mb-0">Start Test</h3>
</div>

                                <?php if (validation_errors()) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo validation_errors();?>

                                </div>

                                <?php } ?>

                                <?php if (isset($error_message)) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $error_message;?>

                                </div>

                                <?php } ?>

                                <?php if (isset($message_display)) {?>

                                <div class="alert alert-success background-success">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $message_display;?>

                                </div>

                                <?php } ?>

                                <?php

                                    $exam_start_time = date('Y-m-d H:i:s', time());

                                    $duration = '40 minute';

                                    $exam_end_time = strtotime($exam_start_time . '+' . $duration);

                                    $exam_end_time = date('Y-m-d H:i:s', $exam_end_time);

                                    

                                    if(!isset($_SESSION['exam_end_time']))

                                    {

                                        $_SESSION['exam_end_time'] = $exam_end_time;

                                    }

                                    if(isset($_SESSION['exam_end_time']))

                                    {

                                       $remaining_minutes = strtotime($_SESSION['exam_end_time']) - time();

                                    }

                                ?>

                                <div class="col-sm-12">  

                                    <div class="pull-right">

                                        <div id="exam_timer" data-timer="<?php echo $remaining_minutes; ?>" style="max-width:400px; width: 100%; height: 200px; position:fixed;"></div>

                                    </div>

                                </div>    

                                <?php $questions = $this->common_model->fetch_data('table_exam', 'paper_id='.$this->uri->segment(3), 'exam_id', 'ASC', '100', '1');?>

                                <div class="col-md-10">

                                    <form role="form" id="ResAdd" name="theForm" method="post" enctype="multipart/form-data" onsubmit="return validate()" data-validate="parsley" >

                                        <?php 

                                        $i = 1;

                                        foreach($questions as $question){?>

                                        <div class="form-group">

                                            <label><strong><?php echo $i;?>) <?php echo $question->question?></strong></label>

                                            <input type="hidden" name="exam_id_<?php echo $i;?>" value="<?php echo $question->exam_id?>">

                                        </div>

                                        <div class="form-group">

                                            <label class="radio-inline">

                                                <input type="radio" name="answer_<?php echo $i;?>" value="A"><?php echo $question->option_a?>

                                            </label> <br />

                                            <label class="radio-inline">

                                                <input type="radio" name="answer_<?php echo $i;?>" value="B"><?php echo $question->option_b?>

                                            </label> <br />

                                            <label class="radio-inline">

                                                <input type="radio" name="answer_<?php echo $i;?>" value="C"><?php echo $question->option_c?>

                                            </label> <br />

                                        </div>

                                        <div class="line line-solid b-b line-lg pull-in"></div>

                                        <?php $i++;} ?>



                                        <input type="submit" class="btn btn-md btn-success" name="submit" id="submit" value="Submit">

                                        <input name="btnBack" type="button" class="btn btn-md btn-default" value="Back to List" size="35" onclick="window.location.href = '<?php echo base_url();?>exam/manage'" />

                                    </form>

                                </div>

                           

<?php $this->load->view('front/includes/footer.php'); ?>



<script>

    $("#exam_timer").TimeCircles({ 

		time:{

			Days:{

				show: false

			},

			Hours:{

				show: false

			}

		}

	});



	setInterval(function(){

		var remaining_second = $("#exam_timer").TimeCircles().getTime();

		if(remaining_second < 1)

		{

            //alert("Times Up !!!");

            $('#submit').click();

            

		}

	}, 1000);



    $(document).ready(function() {

        $("#content").on("contextmenu",function(e){

        return false;

        }); 



        $('#content').bind('copy paste cut',function(e) {

            e.preventDefault(); //disable cut,copy,paste

            alert('cut,copy & paste options are disabled !!');

        });

    }); 



</script>