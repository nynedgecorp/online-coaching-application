<?php $this->load->view('front/includes/header.php'); ?>

<!-- .aside -->

<?php $this->load->view('front/includes/nav.php'); ?>

<!-- /.aside -->

<div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"> Manage Participants</li>
            </ol>
          </nav>
        </div>
        <div class="col-lg-6 col-5 text-right"> <a href="<?php echo base_url();?>student/add"" class="btn btn-md btn-neutral">Add</a> </div>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0"> </div>
<?php if (isset($error_message)) {?>
<div class="alert alert-danger background-danger">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i class="icofont icofont-close-line-circled text-white"></i> </button>
<?php echo $error_message;?>
<?php } ?>
<?php if (isset($message_display)) {?>
<div class="alert alert-success background-success">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i class="icofont icofont-close-line-circled text-white"></i> </button>
<?php echo $message_display;?>
<?php } ?>
<div class="form-group">
<div class="col-sm-4">
  <label for="sort" class="col-sm-6 control-label pull-right"> Filter By </label>
  <select id="select" name="course" onChange="changePage(this)" class="form-control">
    <option value="" selected="selected">All Course</option>
    <?php foreach($courses as $course){?>
    <option value="<?php print $course->course_id;?>" <?php if(isset($_GET['course_id']) && $_GET['course_id'] == $course->course_id){?> selected="selected" <?php }?>><?php print $course->name;?></option>
    <?php } ?>
  </select>
</div>
<?php if($total_rows > 0 && $results == TRUE){

                        $page = $this->uri->segment(3);	

                        $count = ($page > 0) ? (($page - 1)*30 + 1) : 1;?>
<?php foreach($results as $row) {

                        if($row->status == '' || $row->status == 0)

                        {

                            $status = 1 ;

                            $pic = "<img src=\"".base_url()."assets/front/images/status-off.png\"  border=\"0\" />";

                        }

                        else 

                        {  

                            $status = 0 ; 

                            $pic = "<img src=\"".base_url()."assets/front/images/status-on.png\"  border=\"0\" />";

                        }



                        $batch = $this->common_model->get_data('table_batches', 'batch_id', $row->batch_id);

                        $course = $this->common_model->get_data('table_courses', 'course_id', $row->course_id);

                        $phase = $this->common_model->get_data('table_phases', 'phase_id', $row->phase_id);

                            

					          ?>
<div class="col-md-12">
  <div class="card card-stats"> 
    
    <!-- Card body -->
    <div class="card-body">
      <div class="row">
        <div class="col">
          <h5 class="card-title text-uppercase text-muted mb-0">
            <?php if($batch != FALSE) print $batch[0]->batch_no;?>
            &amp;
            <?php if($phase != FALSE) print $phase[0]->name;?>
          </h5>
          <span class="h2 font-weight-bold mb-0"><?php print $row->name;?></span> </div>
        <div class="col-auto">
          <div class="card-profile-image"> 
                
                <img src="https://www.pngkey.com/png/detail/230-2301779_best-classified-apps-default-user-profile.png" class="rounded-circle">
                  </div>
        </div>
      </div>
      <p class="mt-3 mb-0 text-sm"> <span class="text-success mr-2"><i class="fa fa-phone"></i> <?php print $row->email;?></span> <br />
        <span class="text-success mr-2"><i class="ni ni-email-83"></i> <?php print $row->phone;?></span> </p>
      <p class="mt-3 mb-0 text-sm"> <span> <a href="<?php echo base_url();?>student/delete/<?php echo $row->student_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete" class="btn btn-sm m-sp-none btn-danger" id="delete"><i class="ni ni-fat-remove"></i></a> </span> <span> <a href="<?php echo base_url();?>student/edit/<?php echo $row->student_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" class="btn btn-sm m-sp-none btn-warning"><i class="fa fa-wrench"></i></a> </span> <span> <a href="<?php echo base_url();?>student/view/<?php echo $row->student_id;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"class="btn btn-sm m-sp-none btn-primary"><i class="fa fa-eye"></i></a> </span> </p>
      <p class="mt-3 mb-0 text-sm"> <span class="text-nowrap"> 
      
      <a href="<?php echo base_url();?>student/status/<?php echo $row->student_id;?>/<?php echo $status;?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Change Status" ><?php echo $pic;?></a> </span> </p>
    </div>
  </div>
</div>
<div class="table-responsive">
  <table class="table align-items-center table-flush">
    <thead class="thead-light">
    </thead>
    <tbody>
      <?php $count++; } 

                    }else { ?>
      <tr>
        <td colspan="7" style="text-align:center;color:#f00;">No Records Found &nbsp;!</td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
  <ul class="pagi">
    <?php foreach ($links as $link) 

                        {

                        echo "<li>". $link."</li>";

                        } ?>
  </ul>
</div>
<?php $this->load->view('front/includes/footer.php'); ?>
<script type="text/javascript">

  function changePage(obj){

    var course = obj.options[obj.selectedIndex];

      if(course.value == '')

      {

        window.location='<?php echo base_url()?>student/manage';

      }

      else{

        window.location='<?php echo base_url()?>student/manage?course_id='+course.value;

      }

  }

</script>