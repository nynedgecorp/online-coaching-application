<?php $this->load->view('front/includes/header.php'); ?>
        <!-- .aside -->
        <?php $this->load->view('front/includes/nav.php'); ?>
        <!-- /.aside -->
        <section id="content">
          <section class="vbox">
            <section class="scrollable">
              <section class="hbox stretch">
                <aside class="col-lg-6 b-l no-padder">
                  <section class="vbox">
                    <section class="scrollable">
                      <div class="wrapper">
                        <section class="panel panel-default">
                          <h4 class="padder">View Participant</h4>
                            <header class="panel-heading">
                                <a href="<?php echo base_url();?>account/dashboard" class="text-success">Dashboard</a> &nbsp; » &nbsp;<a href="<?php echo base_url();?>student/manage" class="text-success">Manage Participant</a> &nbsp; » &nbsp; View Participant
                            </header>
                          <table class="table table-striped m-b-none" data-ride="datatables">
                            <thead>
                              <tr>
                                <th width="25%">Information</th>
                                <th>Details</th>
                              </tr>
                            </thead>
                            <?php 
                                $batch = $this->common_model->get_data('table_batches', 'batch_id', $result[0]->batch_id);
                                $course = $this->common_model->get_data('table_courses', 'course_id', $result[0]->course_id);
                                $phase = $this->common_model->get_data('table_phases', 'phase_id', $result[0]->phase_id);
                            ?>
                            <tbody>
                                <tr>
                                	<td>Batch</td>
                                    <td><?php if($batch != FALSE) print $batch[0]->batch_no;?></td>
                                </tr>
                                <tr>
                                	<td>Course</td>
                                    <td><?php if($course != FALSE) print $course[0]->name;?></td>
                                </tr>
                                <tr>
                                	<td>Module</td>
                                    <td><?php if($phase != FALSE) print $phase[0]->name;?></td>
                                </tr>
                                <tr>
                                	<td>Name</td>
                                    <td><?php print $result[0]->name;?></td>
                                </tr>
                                <tr>
                                	<td>Email:</td>
                                    <td><?php print $result[0]->email;?></td>
                                </tr>    
                                <tr>
                                	<td>Phone:<br/><p class="text-sm text-success">This will be used as a Username</p></td>
                                    <td><?php print $result[0]->phone;?></td>
                                </tr>    
                                <tr>
                                	<td>Alternate No.:</td>
                                    <td><?php print $result[0]->alternate_no;?></td>
                                </tr>
                                <tr>
                                    <td>Educational / Professional Qualification:</td>
                                    <td>
                                        <table class="table table-bordered table-hover" id="table_education">
                                            <thead>
                                                <tr>
                                                    <th class="text-center"> #</th>
                                                    <th class="text-center">Academic</th>
                                                    <th class="text-center">Division or %</th>
                                                    <th class="text-center">Year of Passing</th>
                                                    <th class="text-center">School / University</th>
                                                    <th class="text-center">Subjects</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td><?php print $result[0]->qual_academic_1;?></td>
                                                    <td><?php print $result[0]->qual_division_1;?></td>
                                                    <td><?php print $result[0]->qual_year_1;?></td>
                                                    <td><?php print $result[0]->qual_school_1;?></td>
                                                    <td><?php print $result[0]->qual_subject_1;?></td>
                                                </tr>
                                                <tr>
                                                    <td>2</td>
                                                    <td><?php print $result[0]->qual_academic_2;?></td>
                                                    <td><?php print $result[0]->qual_division_2;?></td>
                                                    <td><?php print $result[0]->qual_year_2;?></td>
                                                    <td><?php print $result[0]->qual_school_2;?></td>
                                                    <td><?php print $result[0]->qual_subject_2;?></td>
                                                </tr>
                                                <tr>
                                                    <td>3</td>
                                                    <td><?php print $result[0]->qual_academic_3;?></td>
                                                    <td><?php print $result[0]->qual_division_3;?></td>
                                                    <td><?php print $result[0]->qual_year_3;?></td>
                                                    <td><?php print $result[0]->qual_school_3;?></td>
                                                    <td><?php print $result[0]->qual_subject_3;?></td>
                                                </tr>
                                                <tr>
                                                    <td>4</td>
                                                    <td><?php print $result[0]->qual_academic_4;?></td>
                                                    <td><?php print $result[0]->qual_division_4;?></td>
                                                    <td><?php print $result[0]->qual_year_4;?></td>
                                                    <td><?php print $result[0]->qual_school_4;?></td>
                                                    <td><?php print $result[0]->qual_subject_4;?></td>
                                                </tr>
                                                <tr>
                                                    <td>5</td>
                                                    <td><?php print $result[0]->qual_academic_5;?></td>
                                                    <td><?php print $result[0]->qual_division_5;?></td>
                                                    <td><?php print $result[0]->qual_year_5;?></td>
                                                    <td><?php print $result[0]->qual_school_5;?></td>
                                                    <td><?php print $result[0]->qual_subject_5;?></td>
                                                </tr>
                                                <tr>
                                                    <td>6</td>
                                                    <td><?php print $result[0]->qual_academic_6;?></td>
                                                    <td><?php print $result[0]->qual_division_6;?></td>
                                                    <td><?php print $result[0]->qual_year_6;?></td>
                                                    <td><?php print $result[0]->qual_school_6;?></td>
                                                    <td><?php print $result[0]->qual_subject_6;?></td>
                                                </tr>
                                                <tr>
                                                    <td>7</td>
                                                    <td><?php print $result[0]->qual_academic_7;?></td>
                                                    <td><?php print $result[0]->qual_division_7;?></td>
                                                    <td><?php print $result[0]->qual_year_7;?></td>
                                                    <td><?php print $result[0]->qual_school_7;?></td>
                                                    <td><?php print $result[0]->qual_subject_7;?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>    
                                <tr>
                                	<td>Last Qualification / Present Occupation:</td>
                                    <td><?php print $result[0]->qualification;?></td>
                                </tr>
                                <tr>
                                	<td>Last Qualification Marksheet:</td>
                                    <td><?php if($result[0]->qualification_file != ''){?><img src="<?php print base_url();?>/uploads/student/<?php print $result[0]->qualification_file;?>" /><?php } ?></td>
                                </tr>
                                <tr>
                                	<td>Address:</td>
                                    <td><?php print $result[0]->address;?></td>
                                </tr>
                                <tr>
                                	<td>Pin Code:</td>
                                    <td><?php print $result[0]->pin_code;?></td>
                                </tr>
                                <tr>
                                	<td>Gender:</td>
                                    <td><?php print $result[0]->gender;?></td>
                                </tr>
                                <tr>
                                	<td>Date of Admission:</td>
                                    <td><?php print $result[0]->admission_date;?></td>
                                </tr>
                                <tr>
                                	<td>Date of Birth:</td>
                                    <td><?php print $result[0]->dob;?></td>
                                </tr>
                                <tr>
                                	<td>Candidate Type:</td>
                                    <td><?php print $result[0]->candidate_type;?></td>
                                </tr>
                                <tr>
                                	<td>Profile Photo:</td>
                                    <td><?php if($result[0]->photo != ''){?><img src="<?php print base_url();?>/uploads/student/<?php print $result[0]->photo;?>" /><?php } ?></td>
                                </tr>
                                <!--<tr>
                                	<td>Username:</td>
                                    <td><?php print $result[0]->username;?></td>
                                </tr>-->
                                <tr>
                                	<td>Payment Mode:</td>
                                    <td><?php print $result[0]->payment_mode;?></td>
                                </tr>
                                <tr>
                                	<td>Transaction number/ Cheque number/ Draft number:</td>
                                    <td><?php print $result[0]->payment_no;?></td>
                                </tr>
                                <tr>
                                	<td>Payment Date:</td>
                                    <td><?php print $result[0]->payment_date;?></td>
                                </tr>
                          	</tbody>
                          </table>
                          
                          <footer class="panel-footer bg-light lter">
                            <ul class="nav nav-pills nav-sm">
                              <li><button class="btn btn-success pull-right" onclick="window.location.href = '<?php echo base_url();?>student/manage'" >Back to List</button></li>
                            </ul>
                          </footer>
                        </section>
                        
                      </div>
                    </section>
                  </section>              
                </aside>
              </section>
            </section>
          </section>
          <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen,open" data-target="#nav,html"></a>
        </section>
      </section>
    </section>
  </section>
  

<?php $this->load->view('front/includes/footer.php'); ?>

