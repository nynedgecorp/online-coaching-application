<!DOCTYPE html>

<html lang="en">

<head>

    <title><?php print SITE_NAME;?> | <?php print $meta_title;?></title>

    <!-- HTML5 Shim and Respond.js IE10 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 10]>

		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

		<![endif]-->

    <!-- Meta -->

  <link rel="shortcut icon" href="<?php print base_url('assets/front/images/favicon.png');?>">

  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />

  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/bootstrap.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/animate.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/font-awesome.min.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/icon.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/font.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/app.css');?>" type="text/css" />  

  <link rel="stylesheet" href="<?php print base_url('assets/front/js/calendar/bootstrap_calendar.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/style_progress.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/js/datepicker/datepicker.css');?>" type="text/css" />



  <script src="<?php print base_url('assets/front/js/jquery.min.js');?>"></script>

  <!-- Bootstrap -->

  <script src="<?php print base_url('assets/front/js/bootstrap.js');?>"></script>

  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js" ></script>

  



  

</head>



<body>

<section id="content" class="m-t-lg wrapper-md animated fadeInUp">    

    <div class="container">

      <a class="navbar-brand block" href="<?php print base_url();?>"><img alt="" src="<?php print base_url('assets/front/images/Manavpower.png');?>"></a>

      <section class="m-b-lg">

        <header class="wrapper text-center">

          <strong>Please fill out the below form</strong>

        </header>

        <?php if (validation_errors()) {?>

        <div class="alert alert-danger background-danger">

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                <i class="icofont icofont-close-line-circled text-white"></i>

            </button>

            <?php echo validation_errors();?>

        </div>

        <?php } ?>

		<?php if (isset($error_message)) {?>

        <div class="alert alert-danger background-danger">

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                <i class="icofont icofont-close-line-circled text-white"></i>

            </button>

            <?php echo $error_message;?>

        </div>

      <?php } ?>

      <?php if (isset($message_display)) {?>

        <div class="alert alert-success background-success">

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                <i class="icofont icofont-close-line-circled text-white"></i>

            </button>

            <?php echo $message_display;?>

        </div>

       <?php } ?>            

       <form role="form" id="ResAdd" name="theForm" method="post" enctype="multipart/form-data" onsubmit="return validate()" data-validate="parsley" >
       
       

            <div class="col-sm-10">
            
               <div class="form-group">

                    <label>Candidate Type:</label>

                    <select name="candidate_type" class="form-control">

                        <option value="">Select</option>

                        <option value="Professional" <?php if(set_value('candidate_type') == 'Professional'){?> selected <?php }?>>Professional</option>

                        <option value="Student" <?php if(set_value('candidate_type') == 'Student'){?> selected <?php }?>>Student</option>

                    </select>

                </div>

                <div class="form-group">
                    <label>Course:</label>
                    <select name="course_id" class="form-control" data-required="true">
                        <option value="">Select</option>
                        <?php foreach($courses as $course){?>
                        <option value="<?php echo $course->course_id;?>" <?php if($course->course_id == set_value('course_id')){?> selected <?php }?>><?php echo $course->name;?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="form-group">

                    <label>Name:</label>

                    <input type="text" name="name" class="form-control" data-required="true" value="<?php print set_value('name');?>">

                </div>
                
                <div class="form-group">

                    <label>Gender:</label>

                    <label class="radio-inline">

                        <input type="radio" name="gender" value="Male" <?php if(set_value('gender') == 'Male'){?> checked <?php }?>>Male

                    </label>

                    <label class="radio-inline">

                        <input type="radio" name="gender" value="Female" <?php if(set_value('gender') == 'Female'){?> checked <?php }?>>Female

                    </label>

                    <label class="radio-inline">

                        <input type="radio" name="gender" value="Other" <?php if(set_value('gender') == 'Other'){?> checked <?php }?>>Other

                    </label>

                </div>
                
                 <div class="form-group">

                    <label>Address:</label>

                    <textarea name="address" class="form-control" ><?php print set_value('address');?></textarea>

                </div>
                
                  <div class="form-group">

                    <label>Mobile:<br/><p class="text-sm text-success">This will be used as a Username</p></label>

                    <input type="number" name="phone" class="form-control" data-required="true" value="<?php print set_value('phone');?>">

                </div>

                <div class="form-group">

                    <label>Email:</label>

                    <input type="email" name="email" class="form-control" data-parsley-type="email" data-required="true" value="<?php print set_value('email');?>">

                </div>

                  <div class="form-group">

                    <label>Date of Birth:</label>

                    <input type="text" name="dob" id="dob" class="form-control" value="<?php print set_value('dob');?>">

                </div>


                <div class="form-group">

                    <label>Alternate No.:</label>

                    <input type="text" name="alternate_no" class="form-control" value="<?php print set_value('alternate_no');?>">

                </div>

                <div class="form-group">

                    <label>Academic/ Professional Qualification: (10th Onwards) </label>

                    <table class="table table-bordered table-hover" id="table_education">

                        <thead>

                            <tr>

                                <th class="text-center"> #</th>

                                <th class="text-center">Academic</th>

                                <th class="text-center">Division or %</th>

                                <th class="text-center">Year of Passing</th>

                                <th class="text-center">School / University</th>

                                <th class="text-center">Subjects</th>

                            </tr>

                        </thead>

                        <tbody>

                            <tr>

                                <td>1</td>

                                <td><input type="text" class="form-control"  name="qual_academic_1" value="<?php print set_value('qual_academic_1');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_division_1" value="<?php print set_value('qual_division_1');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_year_1" value="<?php print set_value('qual_year_1');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_school_1" value="<?php print set_value('qual_school_1');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_subject_1" value="<?php print set_value('qual_subject_1');?>"></td>

                            </tr>

                            <tr>

                                <td>2</td>

                                <td><input type="text" class="form-control"  name="qual_academic_2" value="<?php print set_value('qual_academic_2');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_division_2" value="<?php print set_value('qual_division_2');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_year_2" value="<?php print set_value('qual_year_2');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_school_2" value="<?php print set_value('qual_school_2');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_subject_2" value="<?php print set_value('qual_subject_2');?>"></td>

                            </tr>

                            <tr>

                                <td>3</td>

                                <td><input type="text" class="form-control"  name="qual_academic_3" value="<?php print set_value('qual_academic_3');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_division_3" value="<?php print set_value('qual_division_3');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_year_3" value="<?php print set_value('qual_year_3');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_school_3" value="<?php print set_value('qual_school_3');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_subject_3" value="<?php print set_value('qual_subject_3');?>"></td>

                            </tr>

                            <tr>

                                <td>4</td>

                                <td><input type="text" class="form-control"  name="qual_academic_4" value="<?php print set_value('qual_academic_4');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_division_4" value="<?php print set_value('qual_division_4');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_year_4" value="<?php print set_value('qual_year_4');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_school_4" value="<?php print set_value('qual_school_4');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_subject_4" value="<?php print set_value('qual_subject_4');?>"></td>

                            </tr>

                            <tr>

                                <td>5</td>

                                <td><input type="text" class="form-control"  name="qual_academic_5" value="<?php print set_value('qual_academic_5');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_division_5" value="<?php print set_value('qual_division_5');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_year_5" value="<?php print set_value('qual_year_5');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_school_5" value="<?php print set_value('qual_school_5');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_subject_5" value="<?php print set_value('qual_subject_5');?>"></td>

                            </tr>

                            <tr>

                                <td>6</td>

                                <td><input type="text" class="form-control"  name="qual_academic_6" value="<?php print set_value('qual_academic_6');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_division_6" value="<?php print set_value('qual_division_6');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_year_6" value="<?php print set_value('qual_year_6');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_school_6" value="<?php print set_value('qual_school_6');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_subject_6" value="<?php print set_value('qual_subject_6');?>"></td>

                            </tr>

                            <tr>

                                <td>7</td>

                                <td><input type="text" class="form-control"  name="qual_academic_7" value="<?php print set_value('qual_academic_7');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_division_7" value="<?php print set_value('qual_division_7');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_year_7" value="<?php print set_value('qual_year_7');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_school_7" value="<?php print set_value('qual_school_7');?>"></td>

                                <td><input type="text" class="form-control"  name="qual_subject_7" value="<?php print set_value('qual_subject_7');?>"></td>

                            </tr>

                        </tbody>

                    </table>

                </div>

                <div class="form-group">

                    <label>Last Qualification / Present Occupation:</label>

                    <input type="text" name="qualification" class="form-control" value="<?php print set_value('qualification');?>">

                </div>

                <div class="form-group">

                    <label>Last Qualification Marksheet:</label>

                    <input type="file" name="qualification_file" class="form-control">

                </div>

               

                <div class="form-group">

                    <label>Pin Code:</label>

                    <input type="text" name="pin_code" class="form-control" value="<?php print set_value('pin_code');?>">

                </div>

                

                <div class="form-group">

                    <label>Date of Admission:</label>

                    <input type="text" name="admission_date" id="admission_date" class="form-control" value="<?php print set_value('admission_date');?>">

                </div>

            
             

                <div class="form-group">

                    <label>Profile Photo:</label>

                    <input type="file" name="photo" class="form-control">

                </div>

                <!--<div class="form-group">

                    <label>Username:</label>

                    <input type="text" name="username" class="form-control" data-required="true" value="<?php print set_value('username');?>">

                </div>-->

                <div class="form-group">

                    <label>Password:</label>

                    <input type="password" name="password" class="form-control" data-required="true">

                </div>

                <div class="form-group">

                    <label>Payment Mode:</label>

                    <select name="payment_mode" id="payment_mode" class="form-control" data-required="true" onchange="hide_div(this);">

                        <option value="">Select</option>

                        <option value="Online" <?php if(set_value('payment_mode') == 'Online'){?> selected <?php }?>>Online</option>

                        <option value="NEFT" <?php if(set_value('payment_mode') == 'NEFT'){?> selected <?php }?>>NEFT</option>

                        <option value="Cheque" <?php if(set_value('payment_mode') == 'Cheque'){?> selected <?php }?>>Cheque</option>

                        <option value="Draft" <?php if(set_value('payment_mode') == 'Draft'){?> selected <?php }?>>Draft</option>

                        <option value="Cash" <?php if(set_value('payment_mode') == 'Cash'){?> selected <?php }?>>Cash</option>

                    </select>

                </div>

                <div class="form-group" id="payment_no" >

                    <label>Transaction number/ Cheque number/ Draft number:</label>

                    <input type="text" name="payment_no" class="form-control" value="<?php print set_value('payment_no');?>">

                </div>

                <div class="form-group">

                    <label>Payment Date:</label>

                    <input type="text" name="payment_date" id="payment_date" class="form-control" value="<?php print set_value('payment_date');?>" data-required="true">

                </div>

                <div class="checkbox">

                    <label>

                      <input type="checkbox" value="1" name="terms" data-required="true" data-parsley-checkmin="1" required>

                      I hereby certify that the information provided by me are true and correct to the best of my knowledge and belief and no information has been suppressed. If any information given above is found to be incorrect, the Management shall be at liberty to take appropriate action, as per company rules.<br/> In case of any change in the particulars provided above will be intimated immediately.

                    </label>

                </div>

            </div>

            <div class="clearfix"></div>

            <div class="line line-dashed b-b line-lg pull-in"></div>



            <input type="submit" class="btn btn-md btn-success" name="submit" id="submit" value="Submit">

        </form>

      </section>

    </div>

  </section>



<?php $this->load->view('front/includes/footer.php'); ?>



<script>

    function hide_div(sel)

    {

        var select_val = sel.value;

        if(select_val == 'Cash')

        {

            $('#payment_no').hide();

        }

        else

        {

            $('#payment_no').show();

        }

    }



    $( function() {

        $( "#admission_date" ).datepicker({

            changeMonth: true,

            changeYear: true,

            dateFormat: 'dd/mm/yy',

            yearRange: "+0:+3",

        });

    } ); 



    $( function() {

        $( "#dob" ).datepicker({

            changeMonth: true,

            changeYear: true,

            dateFormat: 'dd/mm/yy',

            yearRange: "-100:+0",

        });

    } ); 



    $( function() {

        $( "#payment_date" ).datepicker({

            changeMonth: true,

            changeYear: true,

            dateFormat: 'dd/mm/yy',

            yearRange: "+0:+3",

        });

    } );



</script>