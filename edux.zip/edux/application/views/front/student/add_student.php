<?php $this->load->view('front/includes/header.php'); ?>

        <!-- .aside -->

        <?php $this->load->view('front/includes/nav.php'); ?>

<div class="main-content" id="panel">
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>account/dashboard" class="text-default">Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page">Add Participant</li>
              
            </ol>
          </nav>
        </div>
       
      </div>
    </div>
  </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
<div class="row">
<div class="col">
<div class="card">
<!-- Card header -->
<div class="card-header border-0">
  <h3 class="mb-0">Participant Profile Add</h3>
</div>


       

                                <?php if (validation_errors()) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo validation_errors();?>

                                </div>

                                <?php } ?>

                                <?php if (isset($error_message)) {?>

                                <div class="alert alert-danger background-danger">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $error_message;?>

                                </div>

                                <?php } ?>

                                <?php if (isset($message_display)) {?>

                                <div class="alert alert-success background-success">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                        <i class="icofont icofont-close-line-circled text-white"></i>

                                    </button>

                                    <?php echo $message_display;?>

                           

                                <?php } ?>  

                                <div class="col-md-6">

                                    <form role="form" id="ResAdd" name="theForm" method="post" enctype="multipart/form-data" onsubmit="return validate()" data-validate="parsley" >

                                        <div class="form-group">

                                            <label>Batch:</label>

                                            <select name="batch_id" class="form-control" data-required="true">

                                                <option value="">Select</option>

                                                <?php foreach($batches as $batch){?>

                                                <option value="<?php echo $batch->batch_id;?>" <?php if($batch->batch_id == set_value('batch_id')){?> selected <?php }?>><?php echo $batch->batch_no;?></option>

                                                <?php } ?>

                                            </select>

                                        </div>

                                        <div class="form-group">

                                            <label>Course:</label>

                                            <select name="course_id" class="form-control" data-required="true">

                                                <option value="">Select</option>

                                                <?php foreach($courses as $course){?>

                                                <option value="<?php echo $course->course_id;?>" <?php if($course->course_id == set_value('course_id')){?> selected <?php }?>><?php echo $course->name;?></option>

                                                <?php } ?>

                                            </select>

                                        </div>

                                        <div class="form-group">

                                            <label>Module:</label>

                                            <select name="phase_id" class="form-control" data-required="true">

                                                <option value="">Select</option>

                                                <?php foreach($phases as $phase){?>

                                                <option value="<?php echo $phase->phase_id;?>" <?php if($phase->phase_id == set_value('phase_id')){?> selected <?php }?>><?php echo $phase->name;?></option>

                                                <?php } ?>

                                            </select>

                                        </div>

                                        <div class="form-group">

                                            <label>Name:</label>

                                            <input type="text" name="name" class="form-control" data-required="true" value="<?php print set_value('name');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Email:</label>

                                            <input type="email" name="email" class="form-control" data-parsley-type="email" data-required="true" value="<?php print set_value('email');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Phone:<br/><p class="text-sm text-success">This will be used as a Username</p></label>

                                            <input type="number" name="phone" class="form-control" data-required="true" value="<?php print set_value('phone');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Alternate No.:</label>

                                            <input type="text" name="alternate_no" class="form-control" value="<?php print set_value('alternate_no');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Educational / Professional Qualification:</label>

                                            <table class="table table-bordered table-hover" id="table_education">

                                                <thead>

                                                    <tr>

                                                        <th class="text-center"> #</th>

                                                        <th class="text-center">Academic</th>

                                                        <th class="text-center">Division or %</th>

                                                        <th class="text-center">Year of Passing</th>

                                                        <th class="text-center">School / University</th>

                                                        <th class="text-center">Subjects</th>

                                                    </tr>

                                                </thead>

                                                <tbody>

                                                    <tr>

                                                        <td>1</td>

                                                        <td><input type="text" class="form-control"  name="qual_academic_1" value="<?php print set_value('qual_academic_1');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_division_1" value="<?php print set_value('qual_division_1');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_year_1" value="<?php print set_value('qual_year_1');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_school_1" value="<?php print set_value('qual_school_1');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_subject_1" value="<?php print set_value('qual_subject_1');?>"></td>

                                                    </tr>

                                                    <tr>

                                                        <td>2</td>

                                                        <td><input type="text" class="form-control"  name="qual_academic_2" value="<?php print set_value('qual_academic_2');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_division_2" value="<?php print set_value('qual_division_2');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_year_2" value="<?php print set_value('qual_year_2');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_school_2" value="<?php print set_value('qual_school_2');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_subject_2" value="<?php print set_value('qual_subject_2');?>"></td>

                                                    </tr>

                                                    <tr>

                                                        <td>3</td>

                                                        <td><input type="text" class="form-control"  name="qual_academic_3" value="<?php print set_value('qual_academic_3');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_division_3" value="<?php print set_value('qual_division_3');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_year_3" value="<?php print set_value('qual_year_3');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_school_3" value="<?php print set_value('qual_school_3');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_subject_3" value="<?php print set_value('qual_subject_3');?>"></td>

                                                    </tr>

                                                    <tr>

                                                        <td>4</td>

                                                        <td><input type="text" class="form-control"  name="qual_academic_4" value="<?php print set_value('qual_academic_4');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_division_4" value="<?php print set_value('qual_division_4');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_year_4" value="<?php print set_value('qual_year_4');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_school_4" value="<?php print set_value('qual_school_4');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_subject_4" value="<?php print set_value('qual_subject_4');?>"></td>

                                                    </tr>

                                                    <tr>

                                                        <td>5</td>

                                                        <td><input type="text" class="form-control"  name="qual_academic_5" value="<?php print set_value('qual_academic_5');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_division_5" value="<?php print set_value('qual_division_5');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_year_5" value="<?php print set_value('qual_year_5');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_school_5" value="<?php print set_value('qual_school_5');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_subject_5" value="<?php print set_value('qual_subject_5');?>"></td>

                                                    </tr>

                                                    <tr>

                                                        <td>6</td>

                                                        <td><input type="text" class="form-control"  name="qual_academic_6" value="<?php print set_value('qual_academic_6');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_division_6" value="<?php print set_value('qual_division_6');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_year_6" value="<?php print set_value('qual_year_6');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_school_6" value="<?php print set_value('qual_school_6');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_subject_6" value="<?php print set_value('qual_subject_6');?>"></td>

                                                    </tr>

                                                    <tr>

                                                        <td>7</td>

                                                        <td><input type="text" class="form-control"  name="qual_academic_7" value="<?php print set_value('qual_academic_7');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_division_7" value="<?php print set_value('qual_division_7');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_year_7" value="<?php print set_value('qual_year_7');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_school_7" value="<?php print set_value('qual_school_7');?>"></td>

                                                        <td><input type="text" class="form-control"  name="qual_subject_7" value="<?php print set_value('qual_subject_7');?>"></td>

                                                    </tr>

                                                </tbody>

                                            </table>

                                        </div>

                                        <div class="form-group">

                                            <label>Last Qualification / Present Occupation:</label>

                                            <input type="text" name="qualification" class="form-control" value="<?php print set_value('qualification');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Last Qualification Marksheet:</label>

                                            <input type="file" name="qualification_file" class="form-control">

                                        </div>

                                        <div class="form-group">

                                            <label>Address:</label>

                                            <textarea name="address" class="form-control" ><?php print set_value('address');?></textarea>

                                        </div>

                                        <div class="form-group">

                                            <label>Pin Code:</label>

                                            <input type="text" name="pin_code" class="form-control" value="<?php print set_value('pin_code');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Gender:</label>

                                            <label class="radio-inline">

                                                <input type="radio" name="gender" value="Male" <?php if(set_value('gender') == 'Male'){?> checked <?php }?>>Male

                                            </label>

                                            <label class="radio-inline">

                                                <input type="radio" name="gender" value="Female" <?php if(set_value('gender') == 'Female'){?> checked <?php }?>>Female

                                            </label>

                                            <label class="radio-inline">

                                                <input type="radio" name="gender" value="Other" <?php if(set_value('gender') == 'Other'){?> checked <?php }?>>Other

                                            </label>

                                        </div>

                                        <div class="form-group">

                                            <label>Date of Admission:</label>

                                            <input type="text" name="admission_date" id="admission_date" class="form-control" value="<?php print set_value('admission_date');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Date of Birth:</label>

                                            <input type="text" name="dob" id="dob" class="form-control" value="<?php print set_value('dob');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Candidate Type:</label>

                                            <select name="candidate_type" class="form-control">

                                                <option value="">Select</option>

                                                <option value="Professional" <?php if(set_value('candidate_type') == 'Professional'){?> selected <?php }?>>Professional</option>

                                                <option value="Student" <?php if(set_value('candidate_type') == 'Student'){?> selected <?php }?>>Student</option>

                                            </select>

                                        </div>

                                        <div class="form-group">

                                            <label>Profile Photo:</label>

                                            <input type="file" name="photo" class="form-control">

                                        </div>

                                        <!--<div class="form-group">

                                            <label>Username:</label>

                                            <input type="text" name="username" class="form-control" data-required="true" value="<?php print set_value('username');?>">

                                        </div>-->

                                        <div class="form-group">

                                            <label>Password:</label>

                                            <input type="password" name="password" class="form-control" data-required="true">

                                        </div>

                                        <div class="form-group">

                                            <label>Payment Mode:</label>

                                            <select name="payment_mode" id="payment_mode" class="form-control" data-required="true" onchange="hide_div(this);">

                                                <option value="">Select</option>

                                                <option value="Online" <?php if(set_value('payment_mode') == 'Online'){?> selected <?php }?>>Online</option>

                                                <option value="NEFT" <?php if(set_value('payment_mode') == 'NEFT'){?> selected <?php }?>>NEFT</option>

                                                <option value="Cheque" <?php if(set_value('payment_mode') == 'Cheque'){?> selected <?php }?>>Cheque</option>

                                                <option value="Draft" <?php if(set_value('payment_mode') == 'Draft'){?> selected <?php }?>>Draft</option>

                                                <option value="Cash" <?php if(set_value('payment_mode') == 'Cash'){?> selected <?php }?>>Cash</option>

                                            </select>

                                        </div>

                                        <div class="form-group" id="payment_no" >

                                            <label>Transaction number/ Cheque number/ Draft number:</label>

                                            <input type="text" name="payment_no" class="form-control" value="<?php print set_value('payment_no');?>">

                                        </div>

                                        <div class="form-group">

                                            <label>Payment Date:</label>

                                         
                                        </div>
                                        
                                        
                                        <div class="form-group">
    <div class="input-group">
        <div class="input-group-prepend">
            <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
        </div>
     <!--   <input class="form-control datepicker" placeholder="Select date" type="text" value="06/20/2020">-->
        
           <input type="text" name="payment_date" id="payment_date" class="form-control datepicker" value="<?php print set_value('payment_date');?>" data-required="true">

    </div>
</div>

                                        <div class="line line-dashed b-b line-lg pull-in"></div>



                                        <input type="submit" class="btn btn-md btn-success" name="submit" id="submit" value="Submit">

                                        <input name="btnBack" type="button" class="btn btn-md btn-default" value="Back to List" size="35" onclick="window.location.href = '<?php echo base_url();?>student/manage'" />

                                    </form>

                                </div>

                            


<?php $this->load->view('front/includes/footer.php'); ?>
<script src="<?php print base_url('assets/a/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js');?>"></script>


<script>

    function hide_div(sel)

    {

        var select_val = sel.value;

        if(select_val == 'Cash')

        {

            $('#payment_no').hide();

        }

        else

        {

            $('#payment_no').show();

        }

    }



    $( function() {

        $( "#admission_date" ).datepicker({

            changeMonth: true,

            changeYear: true,

            dateFormat: 'dd/mm/yy',

            yearRange: "c+0:c+3",

        });

    } ); 



    $( function() {

        $( "#dob" ).datepicker({

            changeMonth: true,

            changeYear: true,

            dateFormat: 'dd/mm/yy',

            yearRange: "-100:+0",

        });

    } ); 



    $( function() {

        $( "#payment_date" ).datepicker({

            changeMonth: true,

            changeYear: true,

            dateFormat: 'dd/mm/yy',

            yearRange: "c+0:c+3",

        });

    } );



</script>