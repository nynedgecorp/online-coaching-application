<!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="<?php echo base_url();?>account/dashboard">
          <img src="https://www.nynedge.com/wp-content/uploads/2021/03/nynedge.png" class="navbar-brand-img" alt="...">
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
           <li class="<?php if($this->uri->segment(2) == 'dashboard') { echo "class='active'";}?>> nav-item">
              <a class="nav-link" href="<?php print base_url();?>account/dashboard">
                <i class="ni ni-tv-2 text-primary"></i>
                <span class="nav-link-text">Overview</span>
              </a>
            </li>
              <?php if($this->session->userdata['user_logged_in']['rid'] == 1){?>
            <li class="<?php if($this->uri->segment(1) == 'employee') { echo "class='active'";}?>> nav-item">
              <a class="nav-link" href="<?php echo base_url();?>employee/manage">
                <i class="ni ni-single-02 text-orange"></i>
                <span class="nav-link-text">Instructors</span>
              </a>
            </li>
              <?php } ?>
            <li class="nav-item">
              <a class="<?php if($this->session->userdata['user_logged_in']['rid'] == 1 || $this->session->userdata['user_logged_in']['rid'] == 2){?> nav-link" href="<?php echo base_url();?>batch/manage">
                <i class="ni ni-badge text-primary"></i>
                <span class="nav-link-text">Batches</span>
              </a>
            </li>
           
            <li class=" <?php if($this->uri->segment(1) == 'phase') { echo "class='active'";}?> nav-item">
              <a class="nav-link" href="<?php echo base_url();?>phase/manage">
                <i class="ni ni-single-copy-04 text-yellow"></i>
                <span class="nav-link-text">Modules</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="<?php if($this->uri->segment(1) == 'course') { echo "class='active'";}?>> nav-link" href="<?php echo base_url();?>course/manage">
                <i class="ni ni-badge text-default"></i>
                <span class="nav-link-text">Courses</span>
              </a>
            </li>
             <?php } ?>
            <li class="nav-item">
              <a class="<?php if($this->uri->segment(1) == 'act') { echo "class='active'";}?>> nav-link" href="<?php echo base_url();?>act/manage">
                <i class="ni ni-books text-info"></i>
                <span class="nav-link-text">Study Material</span>
              </a>
            </li>
            <?php if($this->session->userdata['user_logged_in']['rid'] == 3){?>
            <li class="nav-item">
              <a class="<?php if($this->uri->segment(2) == 'interactive') { echo "class='active'";}?>> nav-link" href="<?php echo base_url();?>account/interactive">
                <i class="ni ni-ungroup text-pink"></i>
                <span class="nav-link-text">Interactive Session</span>
              </a>
            </li>
              <?php } ?>
              <?php if($this->session->userdata['user_logged_in']['rid'] == 1 || $this->session->userdata['user_logged_in']['rid'] == 2){?>
            <li class="nav-item">
              <a class="<?php if($this->uri->segment(1) == 'student') { echo "class='active'";}?>> nav-link" href="<?php echo base_url();?>student/manage">
                <i class="ni ni-hat-3 text-dark"></i>
                <span class="nav-link-text">Participants</span>
              </a>
            </li>
             <li class="nav-item">
              <a class="<?php if($this->uri->segment(1) == 'paper') { echo "class='active'";}?>> nav-link" href="<?php echo base_url();?>paper/manage">
                <i class="ni ni-send text-pink"></i>
                <span class="nav-link-text">Set Papers</span>
              </a>
            </li>
              <?php } ?>
             <li class="nav-item">
              <a class="<?php if($this->uri->segment(1) == 'practice_exam') { echo "class='active'";}?>> nav-link" href="<?php echo base_url();?>practice_exam/manage">
                <i class="ni ni-watch-time text-dark"></i>
                <span class="nav-link-text">Practice Test</span>
              </a>
            </li>
             <li class="nav-item">
              <a class="<?php if($this->uri->segment(1) == 'exam') { echo "class='active'";}?>> nav-link" href="<?php echo base_url();?>exam/manage">
                <i class="ni ni-time-alarm text-yellow"></i>
                <span class="nav-link-text">Final Exam</span>
              </a>
            </li>
            </ul>
            
              <?php if($this->session->userdata['user_logged_in']['rid'] == 1 || $this->session->userdata['user_logged_in']['rid'] == 2){?>
          <!-- Divider -->
          <hr class="my-3">
          <!-- Heading -->
          <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">Suppot</span>
          </h6>
          <!-- Navigation -->
          <ul class="navbar-nav mb-md-3">
            <li class="nav-item">
              <a class="nav-link" href="#" target="_blank">
                <i class="ni ni-email-83"></i>
                <span class="nav-link-text">Raise Your Ticket</span>
              </a>
            </li>
           </ul>
                   <?php } ?>
        </div>
      </div>
    </div>
  </nav>
   <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </div>
            </li>
           
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
            <li class="nav-item dropdown">
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                  <img src="<?php print base_url('assets/front/images/profile/user-icon.png');?>" alt=" <?php print $this->session->userdata['user_logged_in']['admin_name'];?>">
                  </span>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"> <?php print $this->session->userdata['user_logged_in']['admin_name'];?></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
                <a href="<?php echo base_url();?>account/profile" class="dropdown-item">
                  <i class="ni ni-single-02"></i>
                  <span>My profile</span>
                </a>
               <a href="<?php echo base_url();?>account/password" class="dropdown-item">
                  <i class="ni ni-calendar-grid-58"></i>
                  <span>Change Password</span>
                </a>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-support-16"></i>
                  <span>Support</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="<?php echo base_url();?>account/logout" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Header -->
    <!-- Header -->
 