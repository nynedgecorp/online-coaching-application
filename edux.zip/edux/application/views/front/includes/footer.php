<?php /*?>    <!-- App -->

    <script src="<?php print base_url('assets/front/js/app.js');?>"></script>  

    <script src="<?php print base_url('assets/front/js/slimscroll/jquery.slimscroll.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/easypiechart/jquery.easy-pie-chart.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/sparkline/jquery.sparkline.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/flot/jquery.flot.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/flot/jquery.flot.tooltip.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/flot/jquery.flot.spline.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/flot/jquery.flot.pie.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/flot/jquery.flot.resize.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/flot/jquery.flot.grow.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/charts/flot/demo.js');?>"></script>

    

    <script src="<?php print base_url('assets/front/js/calendar/bootstrap_calendar.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/calendar/demo.js');?>"></script>

    

    <script src="<?php print base_url('assets/front/js/sortable/jquery.sortable.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/app.plugin.js');?>"></script>

    

    <!-- datepicker -->

    <script src="<?php print base_url('assets/front/js/datepicker/bootstrap-datepicker.js');?>"></script>

    <!-- slider -->

    <script src="<?php print base_url('assets/front/js/slider/bootstrap-slider.js');?>"></script>

    <!-- file input -->  

    <script src="<?php print base_url('assets/front/js/file-input/bootstrap-filestyle.min.js');?>"></script>

    

    <script src="<?php print base_url('assets/front/js/chosen/chosen.jquery.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/spinner/jquery.bootstrap-touchspin.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/typehead/typeahead.bundle.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/typehead/demo.js');?>"></script>

    

    <!-- parsley -->

    <script src="<?php print base_url('assets/front/js/parsley/parsley.min.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/parsley/parsley.extend.js');?>"></script>

    







    

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script><?php */?>


<!-- angon -->

<script type="text/javascript" src="<?php echo base_url('assets/a/vendor/jquery/dist/jquery.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/a/vendor/bootstrap/dist/js/bootstrap.bundle.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/a/vendor/js-cookie/js.cookie.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/a/vendor/jquery.scrollbar/jquery.scrollbar.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/a/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/a/vendor/chart.js/dist/Chart.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/a/vendor/chart.js/dist/Chart.extension.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/a/js/argon.js?v=1.2.0'); ?>"></script>

    <script type="text/javascript" src="<?php echo base_url('assets/ckeditor/ckeditor.js'); ?>"></script>

    <script type="text/javascript" src="<?php echo base_url('assets/ckfinder/ckfinder.js'); ?>"></script>
        <script src="<?php print base_url('assets/front/js/app.plugin.js');?>"></script>

    <script src="<?php print base_url('assets/front/js/TimeCircles.js');?>"></script>
<!--angon-->


    <script>

        $(document).on("click", "#delete", function(e){

            e.preventDefault();

            var link = $(this).attr("href");

            swal({

                title: "Are you sure?",

                text: "You want to delete this record!",

                icon: "warning",

                buttons: [

                'No, cancel it!',

                'Yes, I am sure!'

                ],

                dangerMode: true,

            })

            .then((willDelete) => {

                if (willDelete) {

                    window.location.href = link;

                } else {

                swal("Cancelled", "Your record is safe", "error");

                }

            });

        });



        $( function() {

            $( "#datepicker" ).datepicker({

                changeMonth: true,

                changeYear: true,

                dateFormat: 'dd/mm/yy',

                yearRange: "-100:+0",

            });

        } ); 



        $( function() {

            $( "#datepicker1" ).datepicker({

                changeMonth: true,

                changeYear: true,

                dateFormat: 'dd/mm/yy',

                yearRange: "-100:+0",

            });

        } ); 



        $( function() {

            $( "#datepicker2" ).datepicker({

                changeMonth: true,

                changeYear: true,

                dateFormat: 'dd/mm/yy',

                yearRange: "-100:+0",

            });

        } ); 



        CKEDITOR.replace( 'editor1', 

			  { height: '350px',

				width: '100%',

				toolbar : 'Basic',

			});



        CKEDITOR.replace( 'editor2', 

			  { height: '350px',

				width: '100%',

				toolbar : 'Basic',

			});    

       

    </script>    



</body>

</html>

