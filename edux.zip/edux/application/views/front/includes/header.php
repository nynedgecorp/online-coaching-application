<?php /*?><!DOCTYPE html>

<html lang="en" class="app">

<head>

    <title>SMD Future Academy</title>

 



  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />

  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/bootstrap.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/animate.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/font-awesome.min.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/icon.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/font.css');?>" type="text/css" />

  <link rel="stylesheet" href="<?php print base_url('assets/front/css/app.css');?>" type="text/css" />  

  <link rel="stylesheet" href="<?php print base_url('assets/front/js/calendar/bootstrap_calendar.css');?>" type="text/css" />


  <script src="<?php print base_url('assets/front/js/jquery.min.js');?>"></script>

  <!-- Bootstrap -->

  <script src="<?php print base_url('assets/front/js/bootstrap.js');?>"></script>



 
</head><?php */?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Edux - A Coaching Center Application</title>
  <!-- Favicon -->
  <link rel="icon" href="assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="<?php print base_url('assets/a/vendor/nucleo/css/nucleo.css');?>" type="text/css">
  <link rel="stylesheet" href="<?php print base_url('assets/a/vendor/@fortawesome/fontawesome-free/css/all.min.css');?>" type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="<?php print base_url('assets/a/css/argon.css?v=1.2.0');?>" type="text/css">
    <link rel="stylesheet" href="<?php print base_url('assets/front/css/TimeCircles.css');?>" type="text/css" />
      <link rel="stylesheet" href="<?php print base_url('assets/front/css/style_progress.css');?>" type="text/css" />
        <link rel="shortcut icon" href="<?php print base_url('assets/front/images/favicon.png');?>">
        
          <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
   <script>tinymce.init({ selector:'textarea' });</script>
</head>


<body>

