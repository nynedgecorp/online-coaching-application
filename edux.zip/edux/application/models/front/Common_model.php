<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_Model extends CI_Model
{
    function __construct() 
	{
		parent::__construct();
    }
	
	public function add_data($table, $data)
	{
		$this->db->insert($table, $data);
	}
	
	public function record_count($table, $condition) 
	{
		$this->db->select('*');
		$this->db->from($table);
		if($condition)
		{
			$this->db->where($condition);
		}
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->num_rows();
		} 
		else 
		{
			return 0;
		}
	}
	
	public function fetch_data($table, $condition, $pkey, $sort, $limit, $page) 
	{
		$offset = ($page == 1) ? 0 : $limit*($page - 1);
		$this->db->select('*');
		$this->db->from($table);
		if($condition)
		{
			$this->db->where($condition);
		}
		$this->db->limit($limit, $offset);
		$this->db->order_by($pkey, $sort);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
	}
	
	public function get_data($table, $field, $field_val) 
	{
		$condition = "$field='".$field_val."'";
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($condition);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
	}
	
	public function update_data($table, $field, $field_val, $data)
	{
		$this->db->where($field, $field_val);
		$this->db->update($table, $data);
	}

	public function delete_data($table, $field, $field_val)
	{
		$this->db->where($field, $field_val);
		$this->db->delete($table);
    }
    
    public function get_count_by_id($table, $field, $field_val) 
	{
		$condition = "$field='".$field_val."'";
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($condition);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->num_rows();
		} 
		else 
		{
			return false;
		}
    }
    
    public function get_list($table, $condition) 
	{
		$this->db->select('*');
		$this->db->from($table);
		if($condition)
		{
			$this->db->where($condition);
		}
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
    }
    
    public function get_last_id($table, $pkey) 
	{
		$this->db->select('*');
        $this->db->from($table);
        $this->db->limit(1, 0);
		$this->db->order_by($pkey, 'DESC');
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
    }

    public function get_data_where($table, $field, $field_val, $field2, $field_val2) 
	{
		$condition = "$field='".$field_val."' AND $field2='".$field_val2."'";
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($condition);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
    }
    
    public function get_sum($table, $field, $field_val, $field2, $field_val2) 
	{
		$condition = "$field='".$field_val."' AND $field2='".$field_val2."'";
		$this->db->select('SUM(value) as total');
		$this->db->from($table);
		$this->db->where($condition);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
	}
			
}