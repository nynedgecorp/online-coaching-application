<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_Model extends CI_Model
{
    function __construct() 
	{
		parent::__construct();
    }
	
	public function login($data) 
	{
		$condition = "username=" ."'".$data['username']."' AND "."password="."'".$data['password']."' AND status=1";
		$this->db->select('*');
		$this->db->from('table_users');
		$this->db->where($condition);
		$query = $this->db->get();

		if ($query->num_rows() == 1) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
	}
	
	public function get_data($table, $field, $field_val) 
	{
		$condition = "$field='".$field_val."'";
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($condition);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		} 
		else 
		{
			return false;
		}
	}
	
	public function update_data($table, $field, $field_val, $data)
	{
		$this->db->where($field, $field_val);
		$this->db->update($table, $data);
	}
	
	public function check_oldpassword($table, $pkey, $field, $oldpass,$id)
	{
		$this->db->where($pkey, $id);
		$this->db->where($field, md5($oldpass));        
		$query = $this->db->get($table);
		return $query->num_rows(); 
	}			
}